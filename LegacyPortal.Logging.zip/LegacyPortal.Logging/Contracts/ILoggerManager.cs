using System;

namespace LegacyPortal.Logging.Contracts {
    public interface ILoggerManager {
        string GetActivityLogContent (string category, string module, string taskPerformed, string request, string response, string userEmail);
        string GetExceptionLogContent (Exception exception);
        int SaveExceptionLog(Exception exception, string logMessage);

    }
}