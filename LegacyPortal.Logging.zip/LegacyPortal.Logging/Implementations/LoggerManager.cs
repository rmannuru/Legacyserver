using System;
using System.Reflection;
using LegacyPortal.Logging.Contracts;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using LegacyPortal.Shared.AppSettings;
using LegacyPortal.DataAccess.SqlDb.Implementations;
using System.Data.SqlClient;
using LegacyPortal.Shared.Utils;

namespace LegacyPortal.Logging.Implementations
{

    public class LoggerManager :  SqlDataAccess, ILoggerManager {
      
        public LoggerManager(IOptions<DbConfig> dbConfig) : base(dbConfig) { }

        public string GetActivityLogContent (string category, string module, string request, string responseStatus, string response, string userEmail) {
            string result = string.Format ("[Category:{0}][Module:{1}],[Request:{2}],[ResponseStatus:{3}],[Response:{4}],[LoggedInUserEmail:{5}]", category, module, request, responseStatus, response, userEmail);
            result = result.Replace (System.Environment.NewLine, "    ");
            return result;
        }

        public string GetExceptionLogContent (Exception exception) {
            MethodBase site = exception.TargetSite;
            var MethodName = site.Name;
            var SourcePath = site.DeclaringType.FullName;
            var Message = exception.Message;
            var Stacktrace = exception.StackTrace.ToString ();
            string result = string.Format ("[Message:{0}][SourcePath:{1}],[MethodName:{2}][Stacktrace:{3}]", Message, SourcePath, MethodName, Stacktrace);
            result = result.Replace (System.Environment.NewLine, "    ");
            
            return result;
        }

        public int SaveExceptionLog(Exception exception, string logMessage)
        {
            string logData = GetExceptionLogContent(exception);
    
            string query = "[dbo].[SaveExceptionLog]";
            List<DbParameter> dbParameter = new List<DbParameter>();
            dbParameter.Add(new SqlParameter { ParameterName = "@LogData", Value = logData , SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(new SqlParameter { ParameterName = "@LogMessage", Value = logMessage , SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(new SqlParameter { ParameterName = "@CreatedDate", Value = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss") , SqlDbType = SqlDbType.VarChar });
              
            return ExecuteNonQuery((int)DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        
    }
}