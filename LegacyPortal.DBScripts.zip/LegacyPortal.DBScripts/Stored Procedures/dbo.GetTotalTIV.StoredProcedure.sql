USE [LegacyPortal_Dev]
GO
/****** Object:  StoredProcedure [dbo].[GetTotalTIV]    Script Date: 27-12-2019 19:28:48 ******/
DROP PROCEDURE [dbo].[GetTotalTIV]
GO
/****** Object:  StoredProcedure [dbo].[GetTotalTIV]    Script Date: 27-12-2019 19:28:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--EXEC [GetTotalTIV] 'FAC4120','2012-03-11 00:00:00','2012-03-16 07:02:12'

CREATE PROCEDURE [dbo].[GetTotalTIV] (
@PolicyID VARCHAR(256),
@InceptionDate DateTime,
@PostDate DateTime)
AS

BEGIN
  SET NOCOUNT ON
    DECLARE @ErrorNumber int,
          @ErrorMessage varchar(max),
          @ErrorState int,
          @ErrorSeverity int;
  
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
  BEGIN TRANSACTION
    BEGIN TRY

IF OBJECT_ID('tempdb..#TempResult') IS NOT NULL DROP TABLE #TempResult
Create table #TempResult(Limit money,BldgNumber INT,CoverageDescr varchar(256))

INSERT INTO #TempResult(Limit,BldgNumber,CoverageDescr)
SELECT 
coverage.Limit As [Limit],
coverage.BldgNumber AS [BldgNumber],
coverage.CoverageDescr As [CoverageDescr]

FROM
ACAC_Datamart.dbo.PLCoveragePKG coverage
WHERE
 1=
IIF(coverage.EndForm IN ('80F', '80E', '73A', '80E', '80D', '80G', '02', '04', '80A'),1,0) 
AND coverage.PolicyID=@PolicyID
AND coverage.PostDate=@PostDate
 AND coverage.InceptionDate=@InceptionDate 
 AND coverage.CoverageDescr <> '' AND coverage.EndForm <> ''
 

 SELECT CONVERT(VARCHAR(256),Limit) AS Limit ,[BldgNumber],[CoverageDescr]
 FROM #TempResult

 SELECT CONVERT(VARCHAR(256),ISNULL(SUM(Limit),0)) AS TotalTIV FROM #TempResult
 
      IF @@TRANCOUNT > 0
      COMMIT TRANSACTION;

  END TRY
  BEGIN CATCH

    IF @@TRANCOUNT > 0
      ROLLBACK TRANSACTION;

    SET @ErrorNumber = ERROR_NUMBER();
    SET @ErrorMessage = ERROR_MESSAGE();
    SET @ErrorState = ERROR_STATE();
    SET @ErrorSeverity = ERROR_SEVERITY();
    RAISERROR ('%d | %s', @ErrorSeverity, @ErrorState, @ErrorNumber, @ErrorMessage);

  END CATCH
  SET NOCOUNT OFF
END
