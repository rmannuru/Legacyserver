using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace LegacyPortal.DataAccess.Contracts
{
    public interface ISqlDataAccess
    {

        int ExecuteNonQuery(int connectionId,string commandText, List<DbParameter> parameters, CommandType commandType);
        object ExecuteScalar(int connectionId,string commandText, List<DbParameter> parameters);

        DbDataReader GetDataReader(int connectionId,string commandText, List<DbParameter> parameters, CommandType commandType);

        DataSet GetDataSet(int connectionId,string commandText, List<DbParameter> parameters, CommandType commandType);

        DataTable GetDataTable(int connectionId,string commandText, List<DbParameter> parameters, CommandType commandType);
    }
}
