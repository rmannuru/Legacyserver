namespace LegacyPortal.Shared.Utils
{
    public enum DbMapper
    {
        
        LegacyPortal = 0,
        DataMart = 1,
    }
}