
using System;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace LegacyPortal.Shared.FileHandle
{
    public static class FileHandle
    {

        public static byte[] UnzipFromStream(Stream zipStream, string fileName)
        {
            byte[] result = null;

            //One of the approach 
            // System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            // using (MemoryStream memStream = new MemoryStream())
            // {
            //     //zipStream.CopyTo(memStream);
            //     CopyMaybeFaster(zipStream,memStream).Wait();
            //     memStream.Seek(0, SeekOrigin.Begin);
            //     using (Ionic.Zip.ZipFile zip = Ionic.Zip.ZipFile.Read(memStream))
            //     {
            //         var stream=zip.Entries.Where(x=>x.FileName==fileName).Select(x=>x).FirstOrDefault();
            //          result = GetUncompressedPayload(stream.OpenReader());
            //     }
            //     // now use memStream wherever you were previously using responseStream
            // }
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            ZipInputStream zipInputStream = new ZipInputStream(zipStream);
            ZipEntry zipEntry = zipInputStream.GetNextEntry();
            while (zipEntry != null)
            {
                if (zipEntry.IsFile)
                {
                    String entryFileName = zipEntry.Name;
                    byte[] buffer = new byte[4096];     // 4K is optimum
                    if (entryFileName == fileName)
                    {
                        result = GetUncompressedPayload(zipInputStream);
                        break;
                    }
                }
                zipEntry = zipInputStream.GetNextEntry();
            }
            return result;
        }
        // static async Task CopyMaybeFaster(Stream src, Stream dst)
        // {
        //     byte[] buffer = new byte[65536];
        //     int curoff = 0;

        //     Task<int> readTask = src.ReadAsync(buffer, curoff, 32768);
        //     Task writeTask = Task.CompletedTask;
        //     int len;

        //     while ((len = await readTask.ConfigureAwait(false)) != 0)
        //     {
        //         await writeTask.ConfigureAwait(false);
        //         writeTask = dst.WriteAsync(buffer, curoff, len);

        //         curoff ^= 32768;
        //         readTask = src.ReadAsync(buffer, curoff, 32768);
        //     }

        //     await writeTask.ConfigureAwait(false);
        // }
        public static byte[] GetUncompressedPayload(Stream data)
        {
            using (var outputStream = new MemoryStream())
            {
                data.CopyTo(outputStream);
                return outputStream.ToArray();
            }
        }
    }
}