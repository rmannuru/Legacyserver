namespace LegacyPortal.Shared.AppSettings {
    public class DbConfig
    {
        public string DefaultConnectionString { get; set; }
        public string DataMartConnectionString { get; set; }
    }
}