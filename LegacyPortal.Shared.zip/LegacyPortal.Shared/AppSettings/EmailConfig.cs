namespace LegacyPortal.Shared.AppSettings {
    public class EmailConfig {

        public string From { get; set; }
        public string SmtpUserName { get; set; }
        public string SmtpPassword { get; set; }
        public int Port { get; set; }
        public string Host { get; set; }

    }
}