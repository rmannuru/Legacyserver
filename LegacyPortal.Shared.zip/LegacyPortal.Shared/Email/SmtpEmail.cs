using System;
using System.IO;
using System.Net;
using System.Net.Mail;
using LegacyPortal.Contract.Data.Request;
using LegacyPortal.Shared.AppSettings;
using Microsoft.Extensions.Options;

namespace LegacyPortal.Shared.Email {
    public class SmtpEmail {

        private EmailConfig _emailConfig;

        public SmtpEmail (IOptions<EmailConfig> emailConfig) {
            _emailConfig = emailConfig.Value;
         
        }
        public bool Send (EmailRequest email) {
     
                        MailMessage message = new MailMessage ();
                        message.IsBodyHtml = true;
                        message.From = new MailAddress (email.From);
                        if (email.To != null)
                        {
                            foreach (var item in email.To) {
                                message.To.Add (new MailAddress (item));
                            }
                        }
                        if(email.Cc != null) {
                            foreach (var item in email.Cc) {
                                message.CC.Add (new MailAddress (item));
                            }
                        }
                         message.Subject = email.Subject;
                         message.Body = email.Body;

                         if (email.Attachments != null) {
                            foreach (var attachment in email.Attachments) {
                                byte[] bytes = Convert.FromBase64String (attachment.ByteCode);
                                if(attachment.Extension != null)
                                    message.Attachments.Add (new Attachment (new MemoryStream (bytes), attachment.FileName + "." + attachment.Extension));
                                else
                                    message.Attachments.Add (new Attachment (new MemoryStream (bytes), attachment.FileName));
                            }
                        }
                        
                        SmtpClient client = new SmtpClient (_emailConfig.Host, _emailConfig.Port);
                        client.Credentials = new NetworkCredential (_emailConfig.SmtpUserName, _emailConfig.SmtpPassword);
                        client.EnableSsl = true;
                        client.Send (message);
                        return true;
         
        }

    }
}