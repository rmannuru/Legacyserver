using System;
using System.Data.SqlClient;
using LegacyPortal.Contract.Data;
using LegacyPortal.Contract.Data.Request;
using LegacyPortal.DataAccess.SqlDb.Implementations;
using LegacyPortal.Shared.AppSettings;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using LegacyPortal.Shared.Utils;

namespace LegacyPortal.Data.Implementations
{
    public class CommonDataAccess : SqlDataAccess, ICommonDataAccess
    {
        public CommonDataAccess(IOptions<DbConfig> dbConfig) : base(dbConfig) { }

        public int SaveEmailNotificationDetails(EmailNotificationRequest request){
            string query = "[dbo].[SaveEmailNotification]";
            List<DbParameter> dbParameter = new List<DbParameter>();
            dbParameter.Add(item: new SqlParameter { ParameterName = "@SenderDetails", Value = request.SenderDetails, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(item: new SqlParameter { ParameterName = "@ToReceiverDetails", Value = request.ToReceiverDetails, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(item: new SqlParameter { ParameterName = "@CCReceiverDetails", Value = request.ccReceiverDetails, SqlDbType = SqlDbType.VarChar });
          
            dbParameter.Add(item: new SqlParameter { ParameterName = "@FeatureName", Value = request.FeatureName, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(item: new SqlParameter { ParameterName = "@EmailResponse", Value = request.EmailResponse, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(item: new SqlParameter { ParameterName = "@SentDate", Value = request.sentDate.ToString(), SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(item: new SqlParameter { ParameterName = "@IsEmailSent", Value = request.IsMailSent, SqlDbType = SqlDbType.Bit });
            
            return ExecuteNonQuery(connectionId: (int)DbMapper.LegacyPortal, commandText: query, parameters: dbParameter, commandType: CommandType.StoredProcedure);

        }

    }
}