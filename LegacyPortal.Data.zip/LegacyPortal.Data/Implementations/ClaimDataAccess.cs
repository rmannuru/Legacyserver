using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using LegacyPortal.Contract.Data;
using LegacyPortal.Contract.Data.Request;
using LegacyPortal.DataAccess.SqlDb.Implementations;
using LegacyPortal.Shared.AppSettings;
using LegacyPortal.Shared.Utils;
using Microsoft.Extensions.Options;

namespace LegacyPortal.Data.Implementations
{
    public class ClaimDataAccess : SqlDataAccess, IClaimDataAccess
    {
        public ClaimDataAccess(IOptions<DbConfig> dbConfig) : base(dbConfig) { }
        public DbDataReader GetClaimList(GetClaimRequest claimRequest)
        {
            string query = "[dbo].[GetClaims]";

            List<DbParameter> dbParameter = new List<DbParameter>();
            dbParameter.Add(new SqlParameter { ParameterName = "@ClaimNumber", Value = claimRequest.ClaimNumber, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(new SqlParameter { ParameterName = "@PolicyNumber", Value = claimRequest.policyNumber, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(new SqlParameter { ParameterName = "@InsuredName", Value = claimRequest.InsuredName, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(new SqlParameter { ParameterName = "@PageNumber", Value = claimRequest.PageNumber, SqlDbType = SqlDbType.Int });
            dbParameter.Add(new SqlParameter { ParameterName = "@PageSize", Value = claimRequest.PageSize, SqlDbType = SqlDbType.Int });
            dbParameter.Add(new SqlParameter { ParameterName = "@SortOrder", Value = claimRequest.SortOrder, SqlDbType = SqlDbType.Int });
            dbParameter.Add(new SqlParameter { ParameterName = "@SortColumn", Value = claimRequest.SortColumn, SqlDbType = SqlDbType.VarChar });

            return GetDataReader((int)DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);

        }

        public DbDataReader GetClaimByClaimId(string claimNumber)
        {
            string query = "[dbo].[GetClaimInfoByClaimID]";

            List<DbParameter> dbParameter = new List<DbParameter>();
            dbParameter.Add(new SqlParameter { ParameterName = "@ClaimNumber", Value = claimNumber, SqlDbType = SqlDbType.VarChar });

            return GetDataReader((int)DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        public DbDataReader GetClaimsHandling(string claimNumber)
        {
            string query = "[dbo].[GetClaimHandlingInfo]";

            List<DbParameter> dbParameter = new List<DbParameter>();
            dbParameter.Add(new SqlParameter { ParameterName = "@ClaimNumber", Value = claimNumber, SqlDbType = SqlDbType.VarChar });

            return GetDataReader((int)DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        public DbDataReader GetClaimActivitiesList(string claimNumber)
        {
            string query = "[dbo].[GetClaimActivitiesList]";

            List<DbParameter> dbParameter = new List<DbParameter>();
            dbParameter.Add(new SqlParameter { ParameterName = "@ClaimNumber", Value = claimNumber, SqlDbType = SqlDbType.VarChar });

            return GetDataReader((int)DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        public DbDataReader GetPaymentTransactionInfo(string claimNumber)
        {
            string query = "[dbo].[ClaimPaymentTransactions]";

            List<DbParameter> dbParameter = new List<DbParameter>();
            dbParameter.Add(new SqlParameter { ParameterName = "@ClaimNumber", Value = claimNumber, SqlDbType = SqlDbType.VarChar });

            return GetDataReader((int)DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        public DbDataReader GetCheckDetails(string checkNumber)
        {
            string query = "[dbo].[GetCheckDetails]";

            List<DbParameter> dbParameter = new List<DbParameter>();
            dbParameter.Add(new SqlParameter { ParameterName = "@CheckNumber", Value = checkNumber, SqlDbType = SqlDbType.Int });

            return GetDataReader((int)DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
         }

        public DbDataReader ClaimContactsAndLocation(string claimNumber)
        {
           string query = "[dbo].[ClaimContactAndLocationInfo]";

            List<DbParameter> dbParameter = new List<DbParameter>();
            dbParameter.Add(new SqlParameter { ParameterName = "@ClaimNumber", Value = claimNumber, SqlDbType = SqlDbType.VarChar });

            return GetDataReader((int)DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
         }

        public DbDataReader GetClaimData(string claimNumber)
        {
            string query = "[dbo].[GetClaimData]";

            List<DbParameter> dbParameter = new List<DbParameter>();
            dbParameter.Add(new SqlParameter { ParameterName = "@ClaimNumber", Value = claimNumber, SqlDbType = SqlDbType.VarChar });

            return GetDataReader((int)DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }
    }
}