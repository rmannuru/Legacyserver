using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using LegacyPortal.Contract.Data;
using LegacyPortal.Contract.Model.Request;
using LegacyPortal.DataAccess.SqlDb.Implementations;
using LegacyPortal.Shared.AppSettings;
using LegacyPortal.Shared.Utils;
using Microsoft.Extensions.Options;

namespace LegacyPortal.Data.Implementations {
    public class PolicyDataAccess : SqlDataAccess, IPolicyDataAccess {
        public PolicyDataAccess (IOptions<DbConfig> dbConfig) : base (dbConfig) { }
         public DbDataReader Get (PolicyRequest policyRequest) {
             
            string query = "[dbo].[GetPolicies]";              
            List<DbParameter> dbParameter = new List<DbParameter> ();

            dbParameter.Add (new SqlParameter { ParameterName = "@PolicyId", Value = policyRequest.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@InsuredName", Value = policyRequest.InsuredName, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@PageNumber", Value = policyRequest.PageNumber, SqlDbType = SqlDbType.Int });
            dbParameter.Add (new SqlParameter { ParameterName = "@PageSize", Value = policyRequest.PageSize, SqlDbType = SqlDbType.Int });
            dbParameter.Add (new SqlParameter { ParameterName = "@SortOrder", Value = policyRequest.SortOrder, SqlDbType = SqlDbType.Int });
            dbParameter.Add (new SqlParameter { ParameterName = "@SortColumn", Value = policyRequest.SortColumn, SqlDbType = SqlDbType.VarChar });
           
            return GetDataReader ((int) DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

         public DbDataReader GetAllPolicyDetailsByPolicyId (PolicyByIdRequest policyRequest) {

            string query = "[dbo].[GetAllPolicyDetailsByPolicyID]";
            List<DbParameter> dbParameter = new List<DbParameter> ();

            dbParameter.Add (new SqlParameter { ParameterName = "@PolicyId", Value = policyRequest.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@InceptionDate", Value = policyRequest.InceptionDate, SqlDbType = SqlDbType.DateTime });
            dbParameter.Add (new SqlParameter { ParameterName = "@postDate", Value = policyRequest.PostDate, SqlDbType = SqlDbType.DateTime });
            
            return GetDataReader ((int) DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        public DbDataReader GetAllCoveragesByPolicyId (PolicyByIdRequest policyRequest) {

            string query = "[dbo].[GetAllCoveragesByPolicyId]";
            List<DbParameter> dbParameter = new List<DbParameter> ();

            dbParameter.Add (new SqlParameter { ParameterName = "@PolicyId", Value = policyRequest.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@InceptionDate", Value = policyRequest.InceptionDate, SqlDbType = SqlDbType.DateTime });
            dbParameter.Add (new SqlParameter { ParameterName = "@postDate", Value = policyRequest.PostDate, SqlDbType = SqlDbType.DateTime });
            
            return GetDataReader ((int) DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

         public DbDataReader GetCoveragesDetailsByProperty (CoveragesByPropertyRequest propertyRequest) {

            string query = "[dbo].[GetCoveragesByPropertyID]";
            List<DbParameter> dbParameter = new List<DbParameter> ();

            dbParameter.Add (new SqlParameter { ParameterName = "@policyId", Value = propertyRequest.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@inceptionDate", Value = propertyRequest.InceptionDate, SqlDbType = SqlDbType.DateTime });
            dbParameter.Add (new SqlParameter { ParameterName = "@postDate", Value = propertyRequest.PostDate, SqlDbType = SqlDbType.DateTime });
            dbParameter.Add (new SqlParameter { ParameterName = "@BuildingNumber", Value = propertyRequest.BuildingNumber, SqlDbType = SqlDbType.Int });
            dbParameter.Add (new SqlParameter { ParameterName = "@PropertyType", Value = propertyRequest.PropertyType, SqlDbType = SqlDbType.VarChar });
            
            return GetDataReader ((int) DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

         public DbDataReader GetNotesByPolicyId (NotesRequest notesRequest) {

            string query = "[dbo].[GetNotesByPolicyId]";
            List<DbParameter> dbParameter = new List<DbParameter> ();

            dbParameter.Add (new SqlParameter { ParameterName = "@PolicyId", Value = notesRequest.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@inceptionDate", Value = notesRequest.InceptionDate, SqlDbType = SqlDbType.DateTime });
            
            return GetDataReader ((int) DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        public DbDataReader GetPremiumFinanceByPolicyId (PolicyByIdRequest financeRequest) {

            string query = "[dbo].[GetPremiumFinanceByPolicyId]";
            List<DbParameter> dbParameter = new List<DbParameter> ();

            dbParameter.Add (new SqlParameter { ParameterName = "@PolicyId", Value = financeRequest.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@inceptionDate", Value = financeRequest.InceptionDate, SqlDbType = SqlDbType.DateTime });
            dbParameter.Add (new SqlParameter { ParameterName = "@PostDate", Value = financeRequest.PostDate, SqlDbType = SqlDbType.DateTime });
            
            return GetDataReader ((int) DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        public DbDataReader GetTransactionAndPaymentInfoByPolicyId (NotesRequest request) {

            string query = "[dbo].[GetTransactionAndPaymentInfoByPolicyID]";
            List<DbParameter> dbParameter = new List<DbParameter> ();

            dbParameter.Add (new SqlParameter { ParameterName = "@PolicyId", Value = request.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@inceptionDate", Value = request.InceptionDate, SqlDbType = SqlDbType.DateTime });
            
            return GetDataReader ((int) DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        public DbDataReader GetClaimsByPolicyId (PolicyByIdRequest claimRequest) {

            string query = "[dbo].[GetClaimsByPolicyId]";
            List<DbParameter> dbParameter = new List<DbParameter> ();

            dbParameter.Add (new SqlParameter { ParameterName = "@PolicyId", Value = claimRequest.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@inceptionDate", Value = claimRequest.InceptionDate, SqlDbType = SqlDbType.DateTime });
            dbParameter.Add (new SqlParameter { ParameterName = "@PostDate", Value = claimRequest.PostDate, SqlDbType = SqlDbType.DateTime });
            
            return GetDataReader ((int) DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        public DbDataReader GetPostDates (NotesRequest request) {

            string query = "[dbo].[GetPostDatesByPolicyId]";
            List<DbParameter> dbParameter = new List<DbParameter> ();

            dbParameter.Add (new SqlParameter { ParameterName = "@PolicyId", Value = request.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@InceptionDate", Value = request.InceptionDate, SqlDbType = SqlDbType.DateTime });
            
            return GetDataReader ((int) DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
            
        }

        public DbDataReader GetMortgageLossPayeeDetail (MortgageLossPayeeRequest mortgageRequest) {

            string query = "[dbo].[GetMortgageLossPayeeDetail]";
            List<DbParameter> dbParameter = new List<DbParameter> ();

            dbParameter.Add (new SqlParameter { ParameterName = "@PolicyId", Value = mortgageRequest.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add (new SqlParameter { ParameterName = "@inceptionDate", Value = mortgageRequest.InceptionDate, SqlDbType = SqlDbType.DateTime });
            dbParameter.Add (new SqlParameter { ParameterName = "@PostDate", Value = mortgageRequest.PostDate, SqlDbType = SqlDbType.DateTime });
            
            return GetDataReader ((int) DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }

        public DbDataReader GetTotalTIVDetails(PolicyByIdRequest request)
        {

            string query = "[dbo].[GetTotalTIV]";
            List<DbParameter> dbParameter = new List<DbParameter>();

            dbParameter.Add(new SqlParameter { ParameterName = "@PolicyID", Value = request.PolicyId, SqlDbType = SqlDbType.VarChar });
            dbParameter.Add(new SqlParameter { ParameterName = "@InceptionDate", Value = request.InceptionDate, SqlDbType = SqlDbType.DateTime });
            dbParameter.Add(new SqlParameter { ParameterName = "@PostDate", Value = request.PostDate, SqlDbType = SqlDbType.DateTime });

            return GetDataReader((int)DbMapper.LegacyPortal, query, dbParameter, CommandType.StoredProcedure);
        }
    }
}
