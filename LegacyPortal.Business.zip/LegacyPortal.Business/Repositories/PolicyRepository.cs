using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using LegacyPortal.Contract.Classes;
using LegacyPortal.Contract.Data;
using LegacyPortal.Contract.Model.Data;
using LegacyPortal.Contract.Model.Request;
using LegacyPortal.Contract.Model.Response;
using LegacyPortal.Contract.Repositories;

namespace LegacyPortal.Business.Repositories {

    public class PolicyRepository : IPolicyRepository {
        private IPolicyDataAccess _policyDataAccess;
        public PolicyRepository (IPolicyDataAccess policyDataAccess) {
            _policyDataAccess = policyDataAccess;
        }

        /// <summary>
        /// returns list of policies.
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public BriefPolicyResponse Get (PolicyRequest policyRequest) {
            try{
            int count = 0;
            TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                using (DbDataReader dataReader = _policyDataAccess.Get (policyRequest)) {
                 List<Policy> policies = dataReader.ToCustomList<Policy> ();
                    if (dataReader.NextResult ()) {
                        if (dataReader.Read ()) {
                        count = (int) dataReader["Count"];
                        }
                }
                BriefPolicyResponse result = new BriefPolicyResponse ();
                    if (policies == null) {
                    result.Data = new List<Policy> ();
                    } else {
                    result.Data = policies;
                    }
                if(policies!=null){
                    foreach (var pd in policies) {
                    pd.PremisesAddress = textInfo.ToTitleCase(!string.IsNullOrEmpty(pd.PremisesAddress)?pd.PremisesAddress.ToLower ():"");
                    }
                }
                result.recordsFiltered = count;
                result.RecordsTotal = count;
                return result;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// returns Policy info, insured info and Endorsement list.
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        public AllPolicyResponse GetAllPolicyDetailsByPolicyId(PolicyByIdRequest policyrequest) {
            try{
                using (DbDataReader dataReader = _policyDataAccess.GetAllPolicyDetailsByPolicyId(policyrequest)) {
                TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                AllPolicyResponse result = dataReader.ToCustomEntity<AllPolicyResponse>();
               
                 if(dataReader.NextResult()){
                     result.insuredInfo= dataReader.ToCustomEntity<InsuredInfo>();
                    dataReader.NextResult();
                    result.endorsementInfo= dataReader.ToCustomList<EndorsementResponse>();
                 }
                if(result!=null){
                    foreach (var pd in result.TerritoryId) {
                    result.TerritoryId = textInfo.ToTitleCase(!string.IsNullOrEmpty(result.TerritoryId)?result.TerritoryId.ToLower ():"");
                    }
                    foreach (var pd in result.PremisesAddress) {
                    result.PremisesAddress = textInfo.ToTitleCase(!string.IsNullOrEmpty(result.PremisesAddress)?result.PremisesAddress.ToLower ():"");
                    }
                }

                return result;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
           
        /// <summary>
        /// returns Policy coverage, Building detail and Outdoor property detail
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        public AllCoveragesResponse GetAllCoveragesByPolicyId(PolicyByIdRequest policyrequest) {
        try{
            using (DbDataReader dataReader = _policyDataAccess.GetAllCoveragesByPolicyId(policyrequest)) 
            {
                 TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
               AllCoveragesResponse result = new AllCoveragesResponse();
               result.policyCoverages= dataReader.ToCustomList<PolicyCoverageInfo>();

                 if(dataReader.NextResult()){
                     result.buildingCoverages= dataReader.ToCustomList<BuildingCoveragesInfo>();
                    dataReader.NextResult();
                    result.outdoorProperty= dataReader.ToCustomList<OutdoorPropertyResponse>();
                 }
                if(result.buildingCoverages != null){
                    foreach (var pd in result.buildingCoverages) {
                    pd.Address = textInfo.ToTitleCase(!string.IsNullOrEmpty(pd.Address)?pd.Address.ToLower ():"");
                    }
                 }
                if(result.outdoorProperty != null){
                    foreach (var pd in result.outdoorProperty) {
                    pd.Address = textInfo.ToTitleCase(!string.IsNullOrEmpty(pd.Address)?pd.Address.ToLower ():"");
                    }
                }
                
             return result;
            }
        }
         catch(Exception ex)
                {
                    throw ex;
                }
        }

         /// <summary>
        /// returns coverages details based on building number
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public CoverageResponse GetCoveragesDetailsByProperty(CoveragesByPropertyRequest propertyRequest)
        {
            try{
            using (DbDataReader dataReader = _policyDataAccess.GetCoveragesDetailsByProperty(propertyRequest)) {
                CoverageResponse result = new CoverageResponse ();
                List<CoverageInfo> coverageInfo = dataReader.ToCustomList<CoverageInfo> ();
                result.coverageInfo = new List<CoverageInfo> ();

                if (coverageInfo != null) {
                    result.coverageInfo = coverageInfo;
                }
                return result;
                }
            }
                catch(Exception ex)
                {
                    throw ex;
                }
        }

        /// <summary>
        /// returns note details 
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public NotesResponse GetNotesByPolicyId(NotesRequest notesRequest)
        {
            try{
                
            using (DbDataReader dataReader = _policyDataAccess.GetNotesByPolicyId(notesRequest)) {
                List<NotesInfo> notes = dataReader.ToCustomList<NotesInfo> ();
                NotesResponse result = new NotesResponse ();

                    if (notes == null) {
                    result.notesInfo = new List<NotesInfo> ();
                    } else {
                    result.notesInfo = notes;
                    }

                return result;
                }
            }
            catch(Exception ex)
            {
               throw ex;
            }
        }

        /// <summary>
        /// returns Premium finance info
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public FinanceResponse GetPremiumFinanceByPolicyId(PolicyByIdRequest financeRequest)
        {
            try{
                
            using (DbDataReader dataReader = _policyDataAccess.GetPremiumFinanceByPolicyId(financeRequest)) {
                List<FinanceInfo> finace = dataReader.ToCustomList<FinanceInfo> ();
                FinanceResponse result = new FinanceResponse ();

                    if (finace == null) {
                    result.financeInfo = new List<FinanceInfo> ();
                    } else {
                    result.financeInfo = finace;
                    }

                return result;
                }
            }
            catch(Exception ex)
            {
               throw ex;
            }
        }

        /// <summary>
        /// returns  Transaction and payment details
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public TransactionPaymentResponse GetTransactionAndPaymentInfoByPolicyId(NotesRequest request)
        {
            try{
            using (DbDataReader dataReader = _policyDataAccess.GetTransactionAndPaymentInfoByPolicyId(request)) {
                TransactionPaymentResponse result = new TransactionPaymentResponse();
                 result.transInfo= dataReader.ToCustomList<TransactionInfo>();

                 if(dataReader.NextResult()){
                     result.paymentInfo= dataReader.ToCustomList<PaymentInfo>();
                 }
                return result;
                }
            }
            catch(Exception ex)
            {
               throw ex;
            }
        }

        /// <summary>
        /// returns  claims info by policyId
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public ClaimsByPolicyIdResponse GetClaimsByPolicyId(PolicyByIdRequest claimRequest)
        {
            try{
            using (DbDataReader dataReader = _policyDataAccess.GetClaimsByPolicyId(claimRequest)) {
                ClaimsByPolicyIdResponse result = new ClaimsByPolicyIdResponse ();
                List<ClaimsByPolicyIdInfo> claimInfo = dataReader.ToCustomList<ClaimsByPolicyIdInfo> ();
                
                if (claimInfo == null) {
                    result.Data = new List<ClaimsByPolicyIdInfo> ();
                    } else {
                    result.Data = claimInfo;
                    }

                return result;
                }
            }
            catch(Exception ex)
            {
               throw ex;
            }
        }

        /// <summary>
        /// returns  post dates
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public PostDatesResponse GetPostDates(NotesRequest postDatesRequest)
        {
            try{
            using (DbDataReader dataReader = _policyDataAccess.GetPostDates(postDatesRequest)) 
            {
                PostDatesResponse result = new PostDatesResponse ();
                List<PostDateInfo> postDateInfo = dataReader.ToCustomList<PostDateInfo> ();
                
                if (postDateInfo == null) {
                    result.postDateInfo = new List<PostDateInfo> ();
                    } else {
                    result.postDateInfo = postDateInfo;
                    }

                return result;
                }
            }
            catch(Exception ex)
            {
               throw ex;
            }
        }

        public MortgageLossPayeeResponse GetMortgageLossPayeeDetail(MortgageLossPayeeRequest policyRequest)
        {
            try{
            using (DbDataReader dataReader = _policyDataAccess.GetMortgageLossPayeeDetail(policyRequest)) 
            {
                MortgageLossPayeeResponse result = new MortgageLossPayeeResponse ();
                List<MortgageResponse> mortgageDetail = dataReader.ToCustomList<MortgageResponse> ();
                result.MortgageDetail = mortgageDetail;

                 if(dataReader.NextResult()){
                    List<LossPayeeResponse> lossPayeeDetail = dataReader.ToCustomList<LossPayeeResponse> ();
                    result.LossPayeeDetail= lossPayeeDetail;
                 }
                
                return result;
            }
            }
            catch(Exception ex)
            {
               throw ex;
            }
        }

        public TotalTIVResponse GetTotalTIVDetails(PolicyByIdRequest policyRequest)
        {
            try
            {
                using (DbDataReader dataReader = _policyDataAccess.GetTotalTIVDetails(policyRequest))
                {
                    TotalTIVResponse result = new TotalTIVResponse();
                    result.TotalTIVDetail = dataReader.ToCustomList<TotalTIVDetail>();
                    if (dataReader.NextResult())
                    {
                        if (dataReader.Read())
                        {
                            result.TotalTIV = (string)dataReader["TotalTIV"];
                        }
                    }
                    return result;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}