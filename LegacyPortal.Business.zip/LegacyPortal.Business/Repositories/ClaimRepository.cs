using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using LegacyPortal.Contract.Classes;
using LegacyPortal.Contract.Data;
using LegacyPortal.Contract.Data.Request;
using LegacyPortal.Contract.Model.Data;
using LegacyPortal.Contract.Model.Response;
using LegacyPortal.Contract.Repositories;
using LegacyPortal.Logging.Contracts;

namespace LegacyPortal.Business.Repositories
{
    public class ClaimRepository : IClaimRepository
    {
        private ILoggerManager _logger;
        private IClaimDataAccess _claimDataAccess;
        public ClaimRepository(ILoggerManager logger, IClaimDataAccess claimDataAccess)
        {
            _claimDataAccess = claimDataAccess;
            _logger = logger;
        }

         /// <summary>
        /// returns claims list.
        /// </summary>
        /// <param name="claimRequest"></param>
        /// <returns></returns>
        public BriefClaimResponse Get(GetClaimRequest claimRequest)
        {

            int count = 0;
            using (DbDataReader dataReader = _claimDataAccess.GetClaimList(claimRequest))
            {
                TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                List<ClaimData> claims = dataReader.ToCustomList<ClaimData>();
                if (dataReader.NextResult())
                {
                    if (dataReader.Read())
                    {
                        count = (int)dataReader["Count"];
                    }
                }
                BriefClaimResponse result = new BriefClaimResponse();
                if (claims == null)
                {
                    result.Data = new List<ClaimData>();
                }
                else
                {
                    result.Data = claims;
                }

                if(claims!= null){
                   foreach(var cd in claims){
                       cd.LocationAddress = textInfo.ToTitleCase(!string.IsNullOrEmpty(cd.LocationAddress)?cd.LocationAddress.ToLower ():"");
                   } 
                }
                result.recordsFiltered = count;
                result.RecordsTotal = count;
                return result;
            }
        }

        public ClaimResponse GetClaimByClaimId(string claimNumber)
        {
            using (DbDataReader dataReader = _claimDataAccess.GetClaimByClaimId(claimNumber))
            {
                TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                ClaimResponse result = new ClaimResponse();

                result.claimInfo= dataReader.ToCustomEntity<ClaimInfo>();

                 if(dataReader.NextResult()){
                     result.claimInsuredInfo= dataReader.ToCustomEntity<ClaimInsuredInfo>();
                    dataReader.NextResult();
                    result.agentInfo= dataReader.ToCustomEntity<AgentInfo>();
                     dataReader.NextResult();
                    result.claimStatusInfo= dataReader.ToCustomEntity<ClaimStatusInfo>();
                    dataReader.NextResult();
                    result.lossInfo= dataReader.ToCustomEntity<LossInfo>();
                 }
                 if(result.claimInfo!=null){
                     foreach(var cd in result.claimInfo.InsuredAddress){
                        result.claimInfo.InsuredAddress = 
                        textInfo.ToTitleCase(!string.IsNullOrEmpty(result.claimInfo.InsuredAddress)?result.claimInfo.InsuredAddress.ToLower ():"");
                    }
                    foreach(var cd in result.claimInfo.County){
                        result.claimInfo.County = 
                        textInfo.ToTitleCase(!string.IsNullOrEmpty(result.claimInfo.County)?result.claimInfo.County.ToLower ():"");
                    }
                 }
                 if(result.lossInfo!=null){
                     foreach(var cd in result.lossInfo.Address){
                        result.lossInfo.Address = 
                        textInfo.ToTitleCase(!string.IsNullOrEmpty(result.lossInfo.Address)?result.lossInfo.Address.ToLower ():"");
                     }
                     foreach(var cd in result.lossInfo.City){
                        result.lossInfo.City = 
                        textInfo.ToTitleCase(!string.IsNullOrEmpty(result.lossInfo.City)?result.lossInfo.City.ToLower ():"");
                     }
                 }

                return result;
            }
        }

        public ClaimHandlingResponse GetClaimsHandling(string claimNumber)
        {
            using (DbDataReader dataReader = _claimDataAccess.GetClaimsHandling(claimNumber))
            {
                ClaimHandlingResponse result = new ClaimHandlingResponse();

                result.authorityInformation= dataReader.ToCustomEntity<AuthorityInformation>();

                 if(dataReader.NextResult()){
                    result.specialHandling= dataReader.ToCustomEntity<SpecialHandling>();
                    dataReader.NextResult();
                    result.claimsHandling= dataReader.ToCustomEntity<ClaimsHandling>();
                    dataReader.NextResult();
                    result.dwellingInfo= dataReader.ToCustomEntity<DwellingInfo>();
                 }

                return result;
            }
        }

        public ClaimActivitiesResponse GetClaimActivitiesList(string claimNumber)
        {
            using (DbDataReader dataReader = _claimDataAccess.GetClaimActivitiesList(claimNumber))
            {
                ClaimActivitiesResponse result = new ClaimActivitiesResponse();
                List<ClaimActivitiesInfo> claimActivities = dataReader.ToCustomList<ClaimActivitiesInfo> ();

                 if (claimActivities == null) {
                    result.claimActivitiesInfo = new List<ClaimActivitiesInfo> ();
                    } else {
                    result.claimActivitiesInfo = claimActivities;
                    }
                return result;
            }
        }

        public ClaimPaymentTransactionResponse GetPaymentTransactionInfo(string claimNumber)
        {
           using (DbDataReader dataReader = _claimDataAccess.GetPaymentTransactionInfo(claimNumber))
            {
                ClaimPaymentTransactionResponse result = new ClaimPaymentTransactionResponse();
                result.claimTransaction = dataReader.ToCustomList<ClaimTransaction> ();
                
                return result;
            }
        }

        public CheckDetailsResponse GetCheckDetails(string checkNumber)
        {
            using (DbDataReader dataReader = _claimDataAccess.GetCheckDetails(checkNumber))
            {
                CheckDetailsResponse result = dataReader.ToCustomEntity<CheckDetailsResponse> ();
                return result;
            }
        }

        public ClaimContactsAndLocationResponse ClaimContactsAndLocation(string claimNumber)
        {
            using (DbDataReader dataReader = _claimDataAccess.ClaimContactsAndLocation(claimNumber))
            {
                ClaimContactsAndLocationResponse result = new ClaimContactsAndLocationResponse();
                result.contacts = dataReader.ToCustomList<Contacts>();
                if(dataReader.NextResult()){
                    result.locations = dataReader.ToCustomList<Locations>();
                }

                return result;
            }
        }

        public ClaimDataResponse GetClaimData(string claimNumber)
        {
            using (DbDataReader dataReader = _claimDataAccess.GetClaimData(claimNumber))
            {
                ClaimDataResponse result = dataReader.ToCustomEntity<ClaimDataResponse> ();
                return result;
            }
        }

    }
}