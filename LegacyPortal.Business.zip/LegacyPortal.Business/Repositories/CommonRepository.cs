using System;
using LegacyPortal.Contract.Repositories;
using LegacyPortal.Contract.Data;
using LegacyPortal.Contract.Data.Request;

namespace LegacyPortal.Business.Repositories
{
    public class CommonRepository : ICommonRepository
    {
        private ICommonDataAccess _commonDataAccess;
        public CommonRepository(ICommonDataAccess commonDataAccess)
        {
            _commonDataAccess = commonDataAccess;
        }
        public int SaveEmailNotificationDetails(EmailNotificationRequest request){
          return _commonDataAccess.SaveEmailNotificationDetails(request);  
        }


    }
}