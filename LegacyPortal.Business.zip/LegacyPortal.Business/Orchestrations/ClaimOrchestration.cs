using LegacyPortal.Contract.Repositories;
using LegacyPortal.Contract.Orchestrations;
using LegacyPortal.Logging.Contracts;
using System.Collections.Generic;
using LegacyPortal.Contract.Model.Response;
using LegacyPortal.Contract.Model.Data;
using LegacyPortal.Contract.Data.Request;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Amazon.Runtime;
using Amazon.S3.Transfer;
using Amazon.S3;
using LegacyPortal.Shared.AppSettings;
using Microsoft.Extensions.Options;
using LegacyPortal.Shared.FileHandle;
using LegacyPortal.Contract.Model.Request;
using static LegacyPortal.Contract.Classes.Constants;

namespace LegacyPortal.Business.Orchestrations {
    public class ClaimOrchestration : IClaimOrchestration {
        private ILoggerManager _logger;
        private IClaimRepository _claimRepository;
         private AWSConfig _awsConfig;

        public ClaimOrchestration (ILoggerManager logger, IClaimRepository claimRepository,IOptions<AWSConfig>  aWSConfig) {
            _claimRepository = claimRepository;
            _logger = logger;
             _awsConfig = aWSConfig.Value;
        }

        /// <summary>
        /// returns list of claims.
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public BriefClaimResponse Get (GetClaimRequest claimRequest) {

            BriefClaimResponse briefClaimResponse = _claimRepository.Get (claimRequest);
            return briefClaimResponse;
        }

        public ClaimResponse GetClaimByClaimId(string claimNumber)
        {
            ClaimResponse claimResponse = _claimRepository.GetClaimByClaimId(claimNumber);
            return claimResponse;
        }

        public ClaimHandlingResponse GetClaimsHandling(string claimNumber)
        {
            ClaimHandlingResponse claimResponse = _claimRepository.GetClaimsHandling(claimNumber);
            return claimResponse;
        }

        public ClaimActivitiesResponse GetClaimActivitiesList(string claimNumber)
        {
            ClaimActivitiesResponse claimResponse = _claimRepository.GetClaimActivitiesList(claimNumber);
            return claimResponse;
        }

        public ClaimPaymentTransactionResponse GetPaymentTransactionInfo(string claimNumber)
        {
            ClaimPaymentTransactionResponse claimResponse = _claimRepository.GetPaymentTransactionInfo(claimNumber);
            
               claimResponse.indemnityReserve=claimResponse.claimTransaction.Where(x=>x.TransType==1).Select(x=> new IndemnityReserve()
               {
                    Id = x.Id,
                    Date=x.Date,
                    Transaction=x.Transaction,
                    Amount=x.Amount,
                    UserID=x.UserID,
                    Check=x.Check,
                    ApprovedBy=x.ApprovedBy,
                    Comment= x.Comment,
                    BuildingNumber=x.BuildingNumber
               }).ToList(); 
              claimResponse.expenseReserve=claimResponse.claimTransaction.Where(x=>x.TransType==2).Select(x=> new ExpenseReserve()
               {
                    Id = x.Id,
                    Date=x.Date,
                    Transaction=x.Transaction,
                    Amount=x.Amount,
                    UserID=x.UserID,
                    Check=x.Check,
                    ApprovedBy=x.ApprovedBy,
                    Comment= x.Comment,
                    BuildingNumber=x.BuildingNumber
               }).ToList(); 
              claimResponse.indemnityPayment=claimResponse.claimTransaction.Where(x=>x.TransType==3).Select(x=> new IndemnityPayment()
               {
                    Id = x.Id,
                    Date=x.Date,
                    Transaction=x.Transaction,
                    Amount=x.Amount,
                    UserID=x.UserID,
                    Check=x.Check,
                    ApprovedBy=x.ApprovedBy,
                    Comment= x.Comment,
                    BuildingNumber=x.BuildingNumber
               }).ToList(); 
               claimResponse.expensePayment=claimResponse.claimTransaction.Where(x=>x.TransType==4).Select(x=> new ExpensePayment()
               {
                    Id = x.Id,
                    Date=x.Date,
                    Transaction=x.Transaction,
                    Amount=x.Amount,
                    UserID=x.UserID,
                    Check=x.Check,
                    ApprovedBy=x.ApprovedBy,
                    Comment= x.Comment,
                    BuildingNumber=x.BuildingNumber
               }).ToList();  

            return claimResponse;
        }

        public CheckDetailsResponse GetCheckDetails(string checkNumber)
        {
            CheckDetailsResponse checkDetailsResponse = _claimRepository.GetCheckDetails(checkNumber);
            return checkDetailsResponse;
        }

        public ClaimContactsAndLocationResponse ClaimContactsAndLocation(string claimNumber)
        {
            ClaimContactsAndLocationResponse claimResponse = _claimRepository.ClaimContactsAndLocation(claimNumber);
            return claimResponse;
        }

         public GetClaimDocumentResponse GetDocumentDetailsfromJson(GetClaimDocumentRequest docRequest)
        {
           GetClaimDocumentResponse Documentresponse = new GetClaimDocumentResponse();
           try{
            BasicAWSCredentials basicCredentials = new BasicAWSCredentials(_awsConfig.AccessKey, _awsConfig.SecretKey);
            TransferUtility fileTransferUtility = new TransferUtility(new AmazonS3Client(_awsConfig.AccessKey, _awsConfig.SecretKey, Amazon.RegionEndpoint.USEast1));
            AmazonS3Client client = new AmazonS3Client(new BasicAWSCredentials(_awsConfig.AccessKey, _awsConfig.SecretKey), Amazon.RegionEndpoint.USEast1);
            TransferUtilityOpenStreamRequest Tobj = new TransferUtilityOpenStreamRequest
            {
                BucketName =  _awsConfig.BucketName,
                Key = docRequest.PolicyId + ".zip"
            };
            var response = fileTransferUtility.OpenStream(Tobj);
            var bytes = FileHandle.UnzipFromStream(response, "index.json");
            var json = Encoding.ASCII.GetString(bytes);
            Documentresponse = JsonConvert.DeserializeObject<GetClaimDocumentResponse>(json);
            Documentresponse.ClaimDocument=Documentresponse.ClaimDocument.Where(x=>x.ClaimNumber==docRequest.ClaimNumber).Select(x=>x).ToList();
            return Documentresponse;
           }
            catch(AmazonS3Exception ex)
           {
               if(ex.StatusCode==System.Net.HttpStatusCode.NotFound )
               {
                   Documentresponse.DocumentNotavailable=true;
               }
               _logger.SaveExceptionLog (ex, ExceptionCategory.GetDocumentsFailed);
               return Documentresponse;
           }
        }

        public ClaimDataResponse GetClaimData(string claimNumber)
        {
            ClaimDataResponse claimResponse = _claimRepository.GetClaimData(claimNumber);
            return claimResponse;
        }
        
    }
}