using System;
using System.Collections.Generic;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Transfer;
using LegacyPortal.Contract.Data.Request;
using LegacyPortal.Contract.Model.Request;
using LegacyPortal.Contract.Model.Response;
using LegacyPortal.Contract.Repositories;
using LegacyPortal.Shared.AppSettings;
using LegacyPortal.Shared.FileHandle;
using Microsoft.Extensions.Options;

namespace LegacyPortal.Business.Orchestrations
{
    public class CommonOrchestration : ICommonOrchestration
    {
        private ICommonRepository _commonRepository;
        private AWSConfig _awsConfig;

        public CommonOrchestration(ICommonRepository commonRepository,IOptions<AWSConfig>  aWSConfig)
        {
            _commonRepository = commonRepository;
            _awsConfig = aWSConfig.Value;
        }
        public int SaveEmailNotificationDetails(EmailNotificationRequest request){
             return _commonRepository.SaveEmailNotificationDetails(request);
        }

        public EmailNotificationRequest GetEmailNotificationRequest(string senderDetails, List<string> ToDetails, List<string> CcDetails, string featureName,  string emailResponse, Boolean IsMailSent)
        {
            EmailNotificationRequest request = new EmailNotificationRequest();
            request.SenderDetails = senderDetails;
            request.ToReceiverDetails = (ToDetails != null) ? string.Join(",", ToDetails.ToArray()): " ";
            request.ccReceiverDetails = (CcDetails != null) ? string.Join(",", CcDetails.ToArray()): " ";
            request.FeatureName = featureName;
            request.EmailResponse = emailResponse;
            request.IsMailSent = IsMailSent;
            request.sentDate = DateTime.Now;
            return request;

        }

        public GetSpecificDocumentResponse GetParticularDocument(GetSpecificDocumentRequest request)
        {
            GetSpecificDocumentResponse getSpecificPolicyResponse=new GetSpecificDocumentResponse();
            BasicAWSCredentials basicCredentials = new BasicAWSCredentials(_awsConfig.AccessKey, _awsConfig.SecretKey);
            TransferUtility fileTransferUtility = new TransferUtility(new AmazonS3Client(_awsConfig.AccessKey, _awsConfig.SecretKey, Amazon.RegionEndpoint.USEast1));
            AmazonS3Client client = new AmazonS3Client(new BasicAWSCredentials(_awsConfig.AccessKey, _awsConfig.SecretKey), Amazon.RegionEndpoint.USEast1);
            TransferUtilityOpenStreamRequest Tobj = new TransferUtilityOpenStreamRequest
            {
                BucketName = _awsConfig.BucketName,
                Key = request.policyNumber + ".zip"
            };
            var response = fileTransferUtility.OpenStream(Tobj);
            request.FileName = request.Type + "/" + request.FileName;
            var bytes = FileHandle.UnzipFromStream(response, request.FileName);
            getSpecificPolicyResponse.fileData= Convert.ToBase64String(bytes);
           
            return getSpecificPolicyResponse;
        }
    }
}