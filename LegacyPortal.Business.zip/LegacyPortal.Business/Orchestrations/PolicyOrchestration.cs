using LegacyPortal.Contract.Repositories;
using LegacyPortal.Contract.Model.Request;
using LegacyPortal.Contract.Model.Response;
using LegacyPortal.Contract.Orchestrations;
using System;
using LegacyPortal.Shared.AppSettings;
using LegacyPortal.Shared.Email;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Hosting;
using Amazon.S3;
using System.IO;
using Amazon.S3.Model;
using System.IO.Compression;
using Amazon.S3.Transfer;
using Amazon.Runtime;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Linq;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;
using System.Text;
using System.Collections.Generic;
using LegacyPortal.Shared.FileHandle;
using LegacyPortal.Logging.Contracts;
using static LegacyPortal.Contract.Classes.Constants;
// using Ionic.Zip;

namespace LegacyPortal.Business.Orchestrations
{
    public class PolicyOrchestration : IPolicyOrchestration
    {
        private IPolicyRepository _policyRepository;
        private SmtpEmail _smtpEmail;
        private EmailConfig _emailConfig;
        private ICommonOrchestration _commonOrchestration;
        private IHostingEnvironment _hostingEnvironment;
        private AWSConfig _awsConfig;
        private ILoggerManager _logger;
        public PolicyOrchestration(IPolicyRepository policyRepository, IOptions<EmailConfig> emailConfig,IOptions<AWSConfig>  aWSConfig, SmtpEmail smtpEmail, ICommonOrchestration commonOrchestration, IHostingEnvironment hostingEnvironment,ILoggerManager logger)
        {

            _policyRepository = policyRepository;
            _emailConfig = emailConfig.Value;
            _smtpEmail = smtpEmail;
            _commonOrchestration = commonOrchestration;
            _hostingEnvironment = hostingEnvironment;
            _awsConfig = aWSConfig.Value;
            _logger=logger;

        }

        /// <summary>
        /// returns list of policies.
        /// </summary>
        /// <param name ="PolicyRequest"></param>
        /// <returns></returns>
        public BriefPolicyResponse Get(PolicyRequest policyRequest)
        {
            try
            {
                return _policyRepository.Get(policyRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// returns Policy info, insured info and Endorsement list.
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        public AllPolicyResponse GetAllPolicyDetailsByPolicyId(PolicyByIdRequest policyRequest)
        {
            try
            {
                return _policyRepository.GetAllPolicyDetailsByPolicyId(policyRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// returns coverage details with outdoor property and building info
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        public AllCoveragesResponse GetAllCoveragesByPolicyId(PolicyByIdRequest policyRequest)
        {
            try
            {
                return _policyRepository.GetAllCoveragesByPolicyId(policyRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// returns  coverages details based on building number
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        public CoverageResponse GetCoveragesDetailsByProperty(CoveragesByPropertyRequest propertyRequest)
        {
            try
            {
                return _policyRepository.GetCoveragesDetailsByProperty(propertyRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// returns Policy notes/notices/memos 
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        public NotesResponse GetNotesByPolicyId(NotesRequest notesRequest)
        {
            try
            {
                return _policyRepository.GetNotesByPolicyId(notesRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// returns Premium finance info
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        public FinanceResponse GetPremiumFinanceByPolicyId(PolicyByIdRequest financeRequest)
        {
            try
            {
                return _policyRepository.GetPremiumFinanceByPolicyId(financeRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// returns Transaction and payment info
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        public TransactionPaymentResponse GetTransactionAndPaymentInfoByPolicyId(NotesRequest request)
        {
            try
            {
                return _policyRepository.GetTransactionAndPaymentInfoByPolicyId(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// returns claims info by PolicyId
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        public ClaimsByPolicyIdResponse GetClaimsByPolicyId(PolicyByIdRequest request)
        {
            try
            {
                return _policyRepository.GetClaimsByPolicyId(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// returns postDates
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        public PostDatesResponse GetPostDates(NotesRequest postDatesRequest)
        {
            try
            {
                return _policyRepository.GetPostDates(postDatesRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public PolicyExport GetDocumentDetailsfromJson(PolicyByIdRequest docRequest)
        {
           PolicyExport policyExport = new PolicyExport();
           try{
            BasicAWSCredentials basicCredentials = new BasicAWSCredentials(_awsConfig.AccessKey, _awsConfig.SecretKey);
            TransferUtility fileTransferUtility = new TransferUtility(new AmazonS3Client(_awsConfig.AccessKey, _awsConfig.SecretKey, Amazon.RegionEndpoint.USEast1));
            AmazonS3Client client = new AmazonS3Client(new BasicAWSCredentials(_awsConfig.AccessKey, _awsConfig.SecretKey), Amazon.RegionEndpoint.USEast1);
            TransferUtilityOpenStreamRequest Tobj = new TransferUtilityOpenStreamRequest
            {
                BucketName =  _awsConfig.BucketName,
                Key = docRequest.PolicyId + ".zip"
            };
            var response = fileTransferUtility.OpenStream(Tobj);
            var bytes = FileHandle.UnzipFromStream(response, "index.json");
            var json = Encoding.ASCII.GetString(bytes);
            policyExport = JsonConvert.DeserializeObject<PolicyExport>(json);
           
            policyExport.ScannedDocument=policyExport.ScannedDocument.Where(x=>x.DocumentExists).Select(x=>x).ToList();
            policyExport.PolicyDocument=policyExport.PolicyDocument.Where(x=>x.InceptionDate==docRequest.InceptionDate && x.DocumentExists).Select(x=>x).ToList();
           
            return policyExport;
           }
           catch(AmazonS3Exception ex)
           {
               if(ex.StatusCode==System.Net.HttpStatusCode.NotFound )
               {
                   policyExport.DocumentNotavailable=true;
               }
               _logger.SaveExceptionLog (ex, ExceptionCategory.GetDocumentsFailed);
               return policyExport;
           }
        }
         

        public MortgageLossPayeeResponse GetMortgageLossPayeeDetail(MortgageLossPayeeRequest policyRequest)
        {
            try
            {
                return _policyRepository.GetMortgageLossPayeeDetail(policyRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public TotalTIVResponse GetTotalTIVDetails(PolicyByIdRequest policyRequest)
        {
            try{
               return _policyRepository.GetTotalTIVDetails(policyRequest);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }       
    }

}