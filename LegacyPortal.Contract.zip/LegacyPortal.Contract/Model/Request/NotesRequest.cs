using System;
using System.ComponentModel.DataAnnotations;
using LegacyPortal.Contract.Classes;

namespace LegacyPortal.Contract.Model.Request {
    public class NotesRequest {
        [Required]
        public string PolicyId { get; set; }
        [Required]
        [MinDateValidation(ErrorMessage = "InceptionDate is required")]
        public DateTime InceptionDate { get; set; }
        
    }
}