using System;
using System.ComponentModel.DataAnnotations;
using LegacyPortal.Contract.Classes;

namespace LegacyPortal.Contract.Model.Request {
    public class PolicyByIdRequest {
        [Required]
        public string PolicyId { get; set; }
        [Required]
        [MinDateValidation(ErrorMessage = "InceptionDate is required")]
        public DateTime InceptionDate { get; set; }
        [Required]
        [MinDateValidation(ErrorMessage = "PostDate is required")]
        public DateTime PostDate{ get; set; }
    }

    public class CoveragesByPropertyRequest {
        [Required]
        public string PolicyId { get; set; }
        [Required]
        [MinDateValidation(ErrorMessage = "InceptionDate is required")]
        public DateTime InceptionDate { get; set; }
        [Required]
        [MinDateValidation(ErrorMessage = "PostDate is required")]
        public DateTime PostDate{ get; set; }
        [Required]
        [Range(0, int.MaxValue)]
        public int? BuildingNumber { get; set; }
        
        [Required]
        public string PropertyType {get;set;}
    }
}