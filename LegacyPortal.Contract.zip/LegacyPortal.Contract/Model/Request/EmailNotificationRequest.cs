using System;
using System.Collections.Generic;
using LegacyPortal.Contract.Model.Data;

namespace LegacyPortal.Contract.Data.Request
{
    public class EmailNotificationRequest
    {
        public string SenderDetails {get;set;}
        public string ToReceiverDetails {get;set;}
        
        public string ccReceiverDetails {get;set;}
        public string FeatureName {get;set;}
        public string EmailResponse {get;set;}
        public DateTime sentDate {get;set;}
        public bool IsMailSent {get;set;}
    }
}