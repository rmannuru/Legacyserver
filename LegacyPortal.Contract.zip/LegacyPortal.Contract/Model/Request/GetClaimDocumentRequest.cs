using System.ComponentModel.DataAnnotations;

namespace LegacyPortal.Contract.Model.Request {
    public class GetClaimDocumentRequest
    {
        [Required]
        public string ClaimNumber{get;set;}
        [Required]
        public string PolicyId{get;set;}
        public string FileName{get;set;}
    }
}
