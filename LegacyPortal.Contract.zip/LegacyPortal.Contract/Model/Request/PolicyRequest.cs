using System;
using System.ComponentModel.DataAnnotations;
using LegacyPortal.Contract.Model.Data;
using Newtonsoft.Json;

namespace LegacyPortal.Contract.Model.Request {
    public class PolicyRequest {
        public string PolicyId { get; set; }
        public string InsuredName { get; set; }
        [Required]
        [Range(0, int.MaxValue)]
        public int? PageNumber { get; set; }
        [Required]
        [Range(0, int.MaxValue)]
        public int? PageSize { get; set; }
        [Required]
        [Range(0, 2)]
        public int? SortOrder { get; set; }
        [Required]
        public string SortColumn { get; set; }
    }
}