using System.ComponentModel.DataAnnotations;

namespace LegacyPortal.Contract.Model.Request {
    public class GetSpecificDocumentRequest {
        
        [Required]
        public string policyNumber { get; set; }
         [Required]
        public string Type { get; set; }
         [Required]
        public string FileName { get; set; }
    }
}

