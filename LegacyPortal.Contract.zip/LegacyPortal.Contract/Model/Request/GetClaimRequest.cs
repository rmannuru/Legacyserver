using System.ComponentModel.DataAnnotations;

namespace LegacyPortal.Contract.Data.Request {
    public class GetClaimRequest {
        
        public string policyNumber { get; set; }
        public string ClaimNumber { get; set; }
        public string InsuredName { get; set; }
        
        [Required]
        [Range(0, int.MaxValue)]
        public int? PageNumber { get; set; }
        
        [Required]
        [Range(0, int.MaxValue)]
        public int? PageSize { get; set; }

        [Required]
        [Range(0, 2)]
        public int? SortOrder { get; set; }

        [Required]
        public string SortColumn { get; set; }

    }
}

