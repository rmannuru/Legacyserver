using System.Collections.Generic;

namespace LegacyPortal.Contract.Data.Request
{
    public class EmailRequest
    {
        public string From { get; set; }
        public List<string> To { get; set; } = null;
        public List<string> Cc { get; set; } = null;
        public string Subject { get; set; } = null;
        public string Body { get; set; } = null;
        public List<EmailAttachments> Attachments { get; set; } = null;
    }
     public class EmailAttachments
     {
         public string ByteCode { get; set; }
         public string FileName { get; set; }
         public string Extension { get; set; } = null;
     }
}