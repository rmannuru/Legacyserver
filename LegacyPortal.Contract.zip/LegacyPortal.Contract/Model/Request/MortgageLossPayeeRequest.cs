using System;
using System.ComponentModel.DataAnnotations;
using LegacyPortal.Contract.Classes;

namespace LegacyPortal.Contract.Model.Request {
    public class MortgageLossPayeeRequest {
        [Required]
        public string PolicyId { get; set; }
        [Required]
        [MinDateValidation(ErrorMessage = "InceptionDate is required")]
        public DateTime InceptionDate { get; set; }
         [Required]
         public bool IsPolicy { get; set; }
        [PolicyOrClaimValidation("PotDate is required for Policy", "PostDate is optional for claims")]       
        public DateTime? PostDate{ get; set; }
    }
}