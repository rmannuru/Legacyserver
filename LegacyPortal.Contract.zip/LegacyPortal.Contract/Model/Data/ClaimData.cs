using System;

namespace LegacyPortal.Contract.Model.Data {
    public class ClaimData {
        public string ClaimNumber { get; set; }
        public string InsuredName { get; set; }
        public DateTime DateOfLoss { get; set; }
        public string PolicyNumber { get; set; }
        public string LocationAddress { get; set; }
        public DateTime InceptionDate { get; set; }
    }
}