using System;
using System.ComponentModel.DataAnnotations;

namespace LegacyPortal.Contract.Model.Data
{
    public class Policy {
        public string PolicyID { get; set; }
        public DateTime PostDate { get; set; }
        public string InsuredName { get; set; }
        public string PolicyType { get; set; }
        public string PreviousPolicy { get; set; }
        public DateTime InceptionDate { get; set; }
        public string PremisesAddress { get; set; }
    }
}