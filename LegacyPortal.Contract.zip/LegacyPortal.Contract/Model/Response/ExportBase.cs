namespace LegacyPortal.Contract.Model.Response {
    public class ExportBase
    {
        public bool DocumentExists { get; set; }
    }
}