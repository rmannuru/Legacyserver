using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class PolicyCoveragesResponse {
     public List<PolicyCoverageInfo> Data { get; set; }
        public string Message { get; set; }
        public int Code { get; set; }
    }
    
    public class PolicyCoverageInfo {
        public string CoverageDescr { get; set; }
        public string Details { get; set; }
    }
    
}