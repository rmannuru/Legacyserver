using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response
{
    public class GetClaimDocumentResponse
    {
        public List<ClaimDocument> ClaimDocument {set; get; }
        public bool DocumentNotavailable{get;set;}
        public string Message{get;set;}
        public int Code{get;set;}

    }
}