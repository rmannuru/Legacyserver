using System;
using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class ClaimsByPolicyIdResponse {
         public List<ClaimsByPolicyIdInfo> Data { get; set; }
         public int Code { get; set; }
        public string Message { get; set; }
    }

  public class ClaimsByPolicyIdInfo {
     public string ClaimID { get; set; }
         public DateTime LossDate { get; set; }
         public string Description { get; set; }
         public string Status { get; set; }
         public decimal IndeminityPayment { get; set; }
         public decimal ExpensePayment { get; set; }
         public decimal IndeminityReserve { get; set; }
         public decimal ExpenseReserve { get; set; }
  }
}