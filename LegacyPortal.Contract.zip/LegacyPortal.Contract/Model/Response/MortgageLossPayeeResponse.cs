using System;
using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class MortgageLossPayeeResponse {
        public List<MortgageResponse> MortgageDetail { get; set; }
        public List<LossPayeeResponse> LossPayeeDetail { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }

    public class MortgageResponse{
        public string Name { get; set; }
        public string Address { get; set; }
        public string LoanID { get; set; }
    }

    public class LossPayeeResponse{
        public string Name { get; set; }
        public string Address { get; set; }
    }
}