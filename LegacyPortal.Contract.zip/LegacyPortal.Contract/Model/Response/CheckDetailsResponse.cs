using System;

namespace LegacyPortal.Contract.Model.Response {
    public class CheckDetailsResponse {
        public int CheckID { get; set; }
        public string InsuredClaimant { get; set; }
        public string InPaymentOf { get; set; }
        public DateTime? Date { get; set; }
        public decimal Pay { get; set; }
        public string ToTheOrderOf { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }
}
