using System;
using System.Collections.Generic;
using LegacyPortal.Contract.Model.Data;

namespace LegacyPortal.Contract.Model.Response {
    public class BriefPolicyResponse {         
        public int RecordsTotal { get; set; }
        public int recordsFiltered { get; set; }
        public List<Policy> Data { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
          
    }
}