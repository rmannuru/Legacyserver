using System;

namespace LegacyPortal.Contract.Model.Response {
    public class PolicyResponse {
        public string PolicyID { get; set; }
        public string InsuredName { get; set; }
        public DateTime InceptionDate { get; set; }
        public DateTime PostDate { get; set; }
        public string ProtectionClass { get; set; }
        public string PreviousPolicyID { get; set; }
        public string PlanID { get; set; }
        public string AgentID { get; set; }
        public string AgentName { get; set; }
        public string ClassType { get; set; }
        public string PremisesAddress { get; set; }
        public string TerritoryID { get; set; }
        public string Company { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }
}