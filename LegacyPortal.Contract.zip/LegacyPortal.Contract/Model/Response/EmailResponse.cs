using Newtonsoft.Json;

namespace LegacyPortal.Contract.Model.Response
{
    public class EmailResponse
    {

        [JsonIgnore]
        public bool IsSuccess {get;set;}
        public string Message {get;set;}
        public int Code {get;set;}

    }
}
