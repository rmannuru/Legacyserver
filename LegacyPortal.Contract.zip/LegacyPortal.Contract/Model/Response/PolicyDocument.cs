using System;
using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
     public class PolicyDocument : ExportBase
    {
        public DateTime InceptionDate { get; set; }
        public DateTime PostDate { get; set; }
        public string FormCode { get; set; }
        public string Description { get; set; }
        public string FileName { get; set; }
        public IEnumerable<string> EndorsementForms { get; set; }

        public PolicyDocument()
        {
            EndorsementForms = new List<string>();
        }
    }
}