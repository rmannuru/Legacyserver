using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class ClaimContactsAndLocationResponse {
        public List<Contacts> contacts { get; set; }
        public List<Locations> locations { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }
    public class Contacts{
        public string Category { get; set; }
        public string Name { get; set; }
        public string BusinessName { get; set; }
        public string Phone { get; set; }
    } 
    public class Locations{
        public string ClaimId { get; set; }
        public int BuildingNumber { get; set; }
        public string LocationAddress { get; set; }
    }

}