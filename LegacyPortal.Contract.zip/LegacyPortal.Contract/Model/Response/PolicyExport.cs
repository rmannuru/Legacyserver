﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LegacyPortal.Contract.Model.Response
{
    public class PolicyExport
    {
        public List<ScannedDocument> ScannedDocument {set; get; }
        public List<PolicyDocument> PolicyDocument { set;get; }
        public string Message{get;set;}
        public int Code{get;set;}
        public bool DocumentNotavailable{get;set;}

    }
}
