using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LegacyPortal.Contract.Model.Response {
    public class GetSpecificDocumentResponse {
        public string fileData{get;set;}
        public int Code { get; set; }
        public string Message { get; set; }
    }
}