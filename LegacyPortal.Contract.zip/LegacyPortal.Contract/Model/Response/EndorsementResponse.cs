using System;

namespace LegacyPortal.Contract.Model.Response {
    public class EndorsementResponse { 
        public DateTime PostDate { get; set; }
        public string TransactionType { get; set; }
        public string TransactionDescr { get; set; }
        public DateTime TransactionEffectiveDate { get; set; } 
        
    }
}