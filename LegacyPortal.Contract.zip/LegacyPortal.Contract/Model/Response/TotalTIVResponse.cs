using System;
using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class TotalTIVResponse {
        public List<TotalTIVDetail> TotalTIVDetail { get; set; }
        public string TotalTIV{get;set;}
        public int Code { get; set; }
        public string Message { get; set; }
    }
    public class TotalTIVDetail{
        public string Limit { get; set; }
        public int BldgNumber { get; set; }
        public string CoverageDescr { get; set; }
    }
}