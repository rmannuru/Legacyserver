using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class CoverageResponse {
        public List<CoverageInfo> coverageInfo{ get; set; }
         public string Message { get; set; }
         public int Code { get; set; }
    }

    public class CoverageInfo{
        public string CoverageDescr { get; set; }
        public string Details { get; set; }
        public bool IsAmount { get; set; }
    }
}