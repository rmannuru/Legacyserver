using System;

namespace LegacyPortal.Contract.Model.Response {
    public class ClaimDataResponse {
        public string ClaimNumber { get; set; }
        public string PolicyNumber { get; set; }
        public DateTime InceptionDate { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }  
    }
}