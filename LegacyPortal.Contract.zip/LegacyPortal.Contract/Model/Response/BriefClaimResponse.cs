using System.Collections.Generic;
using LegacyPortal.Contract.Model.Data;

namespace LegacyPortal.Contract.Model.Response {
    public class BriefClaimResponse {
        public int RecordsTotal { get; set; }
        public int recordsFiltered { get; set; }
        public List<ClaimData> Data { get; set; }

        public int Code { get; set; }
        public string Message { get; set; }
    }
}