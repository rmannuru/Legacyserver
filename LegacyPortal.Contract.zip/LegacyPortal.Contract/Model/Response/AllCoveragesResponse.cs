using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class AllCoveragesResponse { 
        public int Code { get; set; }
        public string Message { get; set; }
        public List<PolicyCoverageInfo> policyCoverages { get; set; }
        public List<BuildingCoveragesInfo> buildingCoverages { get; set; }
        public List<OutdoorPropertyResponse> outdoorProperty { get; set; }

    }
}

    