using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LegacyPortal.Contract.Model.Response {
    public class InsuredResponse {
       public string InsuredName { get; set; }
        public string Name2 { get; set; }
        public string ContactName { get; set; }
        public string CurrentAddress1 { get; set; }
        public string CurrentAddress2 { get; set; }
        public string CurrentCity { get; set; }
        public string CurrentState { get; set; }
        public string Country { get; set; }
        public string CurrentZipcode { get; set; }
        public string WorkPhone { get; set; }
        public string Extension { get; set; }
        
        public int Code { get; set; }
        public string Message { get; set; }
    }

public class InsuredInfo{
        public string InsuredName { get; set; }
        public string Name2 { get; set; }
        public string ContactName { get; set; }
        public string CurrentAddress1 { get; set; }
        public string CurrentAddress2 { get; set; }
        public string CurrentCity { get; set; }
        public string CurrentState { get; set; }
        public string Country { get; set; }
        public string CurrentZipcode { get; set; }
        public string WorkPhone { get; set; }
        public string Extension { get; set; }
}

}