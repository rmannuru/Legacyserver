﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LegacyPortal.Contract.Model.Response
{
       public class ClaimDocument : ExportBase
        {
            public string ClaimNumber { get; set; }
            public long ClaimImageId { get; set; }
            public DateTime DateAdded { get; set; }
            public string ImageName { get; set; }
            public string Description { get; set; }
        }
}
