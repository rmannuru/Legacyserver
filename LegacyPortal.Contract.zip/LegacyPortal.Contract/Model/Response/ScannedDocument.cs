using System;

namespace LegacyPortal.Contract.Model.Response {
   public class ScannedDocument : ExportBase
    {
        public DateTime UploadDate { get; set; }
        public string ImageName { get; set; }
        public string Description { get; set; }
    }
}