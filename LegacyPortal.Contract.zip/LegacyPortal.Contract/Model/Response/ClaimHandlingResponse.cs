namespace LegacyPortal.Contract.Model.Response {
    public class ClaimHandlingResponse {
        public AuthorityInformation authorityInformation { get; set; }
        public SpecialHandling specialHandling { get; set; }
        public ClaimsHandling claimsHandling { get; set; }
        public DwellingInfo dwellingInfo { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }

    public class AuthorityInformation{
        public string AuthorityContacted { get; set; }
        public string DepartmentContacted { get; set; }
        public string CaseNumber { get; set; }
        public string OfficerName { get; set; }
        public string OfficerPhoneNumber { get; set; }
        public string Peril { get; set; }
        public string CustomSubPeril { get; set; }
        public int SeverityLevel { get; set; }
        public string LossDescription { get; set; }
    }
    public class SpecialHandling {
        public string AttorneyRep { get; set; }
        public string PublicAdjuster { get; set; }
        public string AOBReceived { get; set; }
        public string StormCode { get; set; }
        public string Insuit { get; set; }
    }
    public class ClaimsHandling {
        public string IndependentAdjuster { get; set; }
        public string LossTakerName { get; set; }
        public string SplitHandler1 { get; set; }
        public string SplitHandler2 { get; set; }
        public string SplitHandler3 { get; set; }
        public string ContactAssistance { get; set; }
    }

    public class DwellingInfo {
        public string YearRoofInstalled { get; set; }
    }

}