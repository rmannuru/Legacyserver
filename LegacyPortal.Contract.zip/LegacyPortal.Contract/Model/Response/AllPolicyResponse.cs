using System;
using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class AllPolicyResponse {    
       
        //Policy info
        public string PolicyId { get; set; }
        public string InsuredName { get; set; }
        public DateTime InceptionDate { get; set; }
        public DateTime PostDate { get; set; }
        public string ProtectionClass { get; set; }
        public string PreviousPolicyId { get; set; }
        public string PlanId { get; set; }
        public string AgentId { get; set; }
        public string AgentName { get; set; }
        public string ClassType { get; set; }
        public string PremisesAddress { get; set; }
        public string TerritoryId { get; set; }
        public string Company { get; set; }
        public string PolicyType { get; set; }
      
        // insured info 
       public InsuredInfo  insuredInfo  { get; set; }
       
        // endorsement info 
        public List<EndorsementResponse> endorsementInfo { get; set; }
       
        public int Code { get; set; }
        public string Message { get; set; }

    }
}