using System;
using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class TransactionPaymentResponse {
        public List<TransactionInfo> transInfo { get; set; }
        public List<PaymentInfo> paymentInfo { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }

    public class TransactionInfo{
        public DateTime PostDate { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime AccountingDate { get; set; }
        public string TransactionType { get; set; }
        public string TransactionDescr { get; set; }
        public Decimal TrxPremAmt { get; set; }
        public Decimal SubTotal { get; set; }
    }

    public class PaymentInfo{
        public DateTime BatchDate { get; set; }
        public Decimal PaymentAmt { get; set; }
        public string Descr { get; set; }
        public string CheckId { get; set; }
        public string Operator { get; set; }
        public Byte PaymentType { get; set; }
        public int Id { get; set; }
        public Decimal SubTotal { get; set; }
    }

}