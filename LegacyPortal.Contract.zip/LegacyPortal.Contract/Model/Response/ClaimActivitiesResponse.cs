using System;
using System.Collections.Generic;
using LegacyPortal.Contract.Classes;

namespace LegacyPortal.Contract.Model.Response {
    public class ClaimActivitiesResponse {
        public List<ClaimActivitiesInfo> claimActivitiesInfo { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }
    public class ClaimActivitiesInfo{
        public DateTime CreatedDate { get; set; }
        public string UserName { get; set; }
        public string Comment { get; set; }
        public string Subject { get; set; }
    }

}