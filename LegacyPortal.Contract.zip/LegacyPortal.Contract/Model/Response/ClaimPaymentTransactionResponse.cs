using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LegacyPortal.Contract.Model.Response {
    public class ClaimPaymentTransactionResponse {
        public List<IndemnityReserve> indemnityReserve { get; set; }
        public List<IndemnityPayment> indemnityPayment { get; set; }
        public List<ExpenseReserve> expenseReserve { get; set; }
        public List<ExpensePayment> expensePayment { get; set; }
        [JsonIgnore]
        public List<ClaimTransaction> claimTransaction { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }
    public class ClaimTransaction{
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string Transaction { get; set; }
        public int TransType { get; set; }
        public decimal Amount { get; set; }
        public string UserID { get; set; }
        public string Check { get; set; }
        public string ApprovedBy { get; set; }
        public string Comment { get; set; }
        public int BuildingNumber { get; set; }
    }
    public class IndemnityReserve{
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string Transaction { get; set; }
        public decimal Amount { get; set; }
        public string UserID { get; set; }
        public string Check { get; set; }
        public string ApprovedBy { get; set; }
        public string Comment { get; set; }
        public int BuildingNumber { get; set; }
    }
    public class IndemnityPayment{
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string Transaction { get; set; }
        public decimal Amount { get; set; }
        public string UserID { get; set; }
        public string Check { get; set; }
        public string ApprovedBy { get; set; }
        public string Comment { get; set; }
        public int BuildingNumber { get; set; }
    }
    public class ExpenseReserve{
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string Transaction { get; set; }
        public decimal Amount { get; set; }
        public string UserID { get; set; }
        public string Check { get; set; }
        public string ApprovedBy { get; set; }
        public string Comment { get; set; }
        public int BuildingNumber { get; set; }
    }
    public class ExpensePayment{
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string Transaction { get; set; }
        public decimal Amount { get; set; }
        public string UserID { get; set; }
        public string Check { get; set; }
        public string ApprovedBy { get; set; }
        public string Comment { get; set; }
        public int BuildingNumber { get; set; }
    }

}