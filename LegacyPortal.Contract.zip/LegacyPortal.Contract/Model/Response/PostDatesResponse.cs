using System;
using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class PostDatesResponse {
        public List<PostDateInfo> postDateInfo { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }
    public class PostDateInfo{
        public string PolicyId { get; set; }
        public DateTime InceptionDate { get; set; }
        public DateTime PostDate { get; set; }
    }
}