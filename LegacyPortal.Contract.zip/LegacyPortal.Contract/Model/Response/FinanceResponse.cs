using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class FinanceResponse {
        public List<FinanceInfo> financeInfo { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }

    public class FinanceInfo{
        public string Name { get; set; }
        public string Address1 { get; set; }
         public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string LoanId { get; set; }
    }
}