using System;

namespace LegacyPortal.Contract.Model.Response {
    public class ClaimResponse {
        public ClaimInfo claimInfo { get; set; }
        public ClaimInsuredInfo claimInsuredInfo { get; set; }
        public AgentInfo agentInfo { get; set; }
        public ClaimStatusInfo claimStatusInfo { get; set; }
        public LossInfo lossInfo { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }    
    }

    public class ClaimInfo
    {
        public string PolicyNumber { get; set; }
        public string ClaimNumber { get; set; }
        public DateTime InceptionDate { get; set; }
        public string InsuredName { get; set; }
        public DateTime? ReportDate { get; set; }
        public DateTime LossDate { get; set; }
        public string InsuredAddress { get; set; }
        public string claimAdjuster { get; set; }
        public string County { get; set; }
        public string PolicyStatus { get; set; }
        public string PolicyType { get; set; }
        public int AgeOfClaim { get; set; }  
    }

    public class ClaimInsuredInfo
    {
        public string MailingAddress { get; set; }
        public string HomePhone { get; set; }
        public string WorkPhone { get; set; }
        public string CellPhone { get; set; }
        public string Fax { get; set; }
        public string ContactName { get; set; }
        public string Email { get; set; }
    }

    public class AgentInfo
    {
        public string AgencyInformation { get; set; }
        public string Address { get; set; }
        public string PhoneOrFax { get; set; }
        public string Email { get; set; }
    }
    public class ClaimStatusInfo
    {
        public string ClaimStatus { get; set; }
        public DateTime ClosedDate { get; set; }
        public DateTime? ReopenDate { get; set; }
    }
    public class LossInfo
    {
        public string ReportedBy { get; set; }
        public string Phone { get; set; }
        public string LossLocation { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string state { get; set; }
        public string Zip { get; set; }
    }

}