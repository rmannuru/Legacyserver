using System;
using System.Collections.Generic;

namespace LegacyPortal.Contract.Model.Response {
    public class NotesResponse {
        public List<NotesInfo> notesInfo { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
    }

    public class NotesInfo{
        public string Type { get; set; }
        public string UserId { get; set; }
        public DateTime EntryDate { get; set; }
        public string Message { get; set; }
    }
}