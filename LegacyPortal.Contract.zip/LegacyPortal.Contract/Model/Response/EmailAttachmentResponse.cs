using System;
using Newtonsoft.Json;

namespace LegacyPortal.Contract.Model.Response
{
    public class EmailAttachmentResponse
    {
        public bool IsAttachementGenerated { get; set; }
        public bool IsEmailSent {get;set;}
        public int Code { get; set; }
        public string Message { get; set; }
        public byte[] Attachment { get; set; }
        public string Filename {get;set;}
        public string FilePath {get;set;}
        public string FileRootPath {get;set;}
    }
}