using System;

namespace LegacyPortal.Contract.Model.Response {
    public class OutdoorPropertyResponse { 
        public int BldgNumber { get; set; }
        public string Address { get; set; }
        public string YearConstruction { get; set; }
        public string Description { get; set; }
         public int SquareFeet { get; set; }
        public int NoStories { get; set; }
        public string ConstructionType { get; set; }
        public string YearRoofReplaced { get; set; }
        public int BuildingType { get; set; }
        public string PropertyType { get; set; }
    }
}