using System.Net;

namespace LegacyPortal.Contract.Model.Response {
    public class CustomResponse {
       public HttpStatusCode Code { get; set; }

      public  dynamic Value { get; set; }

     public   CustomResponse (HttpStatusCode code, dynamic value) {
            Code = code;
            Value = value;
        }
    }
}