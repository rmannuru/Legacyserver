namespace LegacyPortal.Contract.Error {
    public class ErrorMessage {
        public const string LP_GetPoliciesError = "Unable to fetch Policies";
        public const string LP_PolicyNotFound = "Policy details are not found";
        public const string LP_CoveragesNotFound = "Coverage details not found";
        public const string LP_GetClaimsError = "Unable to fetch claims";
        public const string LP_GetNotesNotFound = "Note details are not found";
        public const string LP_GetFinanceError = "Unable to fetch finance details";
        public const string LP_GetTransactionPaymentError = "Unable to Transation or Payment details";
        public const string LP_GetPostDatesError = "Unable to fetch PostDates";
        public const string LP_DocumentRetrivedError="Document retrived failed";
        public const string LP_GetClaimsByClaimNumberError = "Unable to fetch claim details by claim number";
        public const string LP_GetClaimHandlingInfoError = "Unable to fetch claim handling info";
        public const string LP_ClaimActivitiesListError = "Unable to fetch claim activities list";
        public const string LP_ClaimPaymentTransactionsError = "Unable to fetch claim payment trasaction details";
        public const string LP_GetCheckDetailsError = "Unable to fetch check details of claims";
        public const string LP_ClaimContactsAndLocError = "Unable to fetch claim locations and contact details";
        public const string LP_ClaimDataError = "Unable to fetch claim data";
        public const string LP_GetPropertyCoverageError = "Unable to fetch property coverages";
        public const string LP_DocumentNotFound="Document is not exist";
        public const string LP_GetMortgageLossPayeeDetail = "Unable to fetch Mortgage and Loss payee detail";
        public const string LP_GetTotalTivError="Error in get TotalTiv details";
    }
}