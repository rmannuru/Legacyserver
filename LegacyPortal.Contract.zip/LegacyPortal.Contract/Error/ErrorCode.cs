namespace LegacyPortal.Contract.Error {
    public enum ErrorCode {
        LP_GetPoliciesError = 01,
        LP_PolicyNotFound = 02,
        LP_CoveragesNotFound = 03,
        LP_GetClaimsError = 04,
        LP_GetNotesNotFound = 05,
        LP_GetFinanceError = 06,
        LP_GetTransactionPaymentError = 07,
         LP_GetPostDatesError = 08,
         LP_DocumentRetrivedError=09,
         LP_GetClaimsByClaimNumberError = 10,
         LP_GetClaimHandlingInfoError = 11,
         LP_ClaimActivitiesListError = 12,
         LP_ClaimPaymentTransactionsError = 13,
         LP_GetCheckDetailsError = 14,
        LP_ClaimContactsAndLocError = 15,
        LP_ClaimDataError = 16,
        LP_GetPropertyCoverageError = 17,
        LP_DocumentNotFound=18,
        LP_GetMortgageLossPayeeDetail = 19,
        LP_GetTotalTivError=20
    }
}