
namespace LegacyPortal.Contract.Classes {
    public static class Constants {
        //public const string BadRequest = "Bad request";
        public static class Config {

            public const string AppSettings = "AppSettings";
            public const string DbConfiguration = "DbConfiguration";
            public const string EmailConfig = "EmailConfig";
            public const string AWSConfig="AWSConfig";
        }

        public static class ExceptionCategory
        {
            public const string GetPoliciesFailed = "Legacy - Failed to get policy list information ";
            public const string GetPolicyByPolicyId = "Legacy - Failed to get policy information";
            public const string GetCoveragesFailed = "Legacy - Failed to get coverges information";
            public const string GetClaimsBySearch = "Legacy - Failed to get claims information";
            public const string GetNotesFailed = "Legacy - Failed to get Notes information";
            public const string GetPremiumFinanceFailed = "Legacy - Failed to get premium fincance information";
            public const string GetTransactionPaymentFailed = "Legacy - Failed to get Transaction and payment information";
            public const string GetPostDatesFailed = "Legacy - Failed to get postDates";
            public const string GetDocumentsFailed = "Legacy - Failed to get documents from S3 bucket";
            public const string FailedInMiddleware="Failed in MiddleWare";
            public const string GetClaimInfoFailed = "Legacy - Failed to get claimInfo by claim number";
            public const string ClaimHandlingInfoFailed = "Legacy - Failed to get claim handling Info";
            public const string ClaimActivitiesListFailed = "Legacy - Failed to get claims activities list";
            public const string GetClaimPaymentFailed = "Legacy - Failed to get claims transaction details";
            public const string GetCheckDetailsFailed = "Legacy - Failed to get claims check details";
            public const string ClaimContactsAndLocFailed = "Legacy - Failed to get claims contacts and Location details";
            public const string GetClaimDataFailed = "Legacy - Failed to get claim data";
            public const string GetPropertyCoveragesFailed = "Legacy - Failed to get property coverages";
        }

        public static class EmailNotificationFeatures
        {
            public const string SendEmail = "Send - Email";
        }

        public static class ApplicationException
        {
            public const string InternalServerError = "Internal Server Error";

            public const string NotImplementedException = "Not Implemented";
        }
    }
}