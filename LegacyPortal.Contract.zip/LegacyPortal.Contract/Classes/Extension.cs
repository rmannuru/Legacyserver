using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Reflection;

namespace LegacyPortal.Contract.Classes {
    public static class Extension {
         public static List<T> ToCustomList<T> (this DbDataReader dr) where T : new () {
            List<T> entitiesList = null;
            var entity = typeof (T);
            var propDict = new Dictionary<string, PropertyInfo> ();
            try {
                if (dr != null && dr.HasRows) {
                    entitiesList = new List<T> ();
                    var property = entity.GetProperties (BindingFlags.Instance | BindingFlags.Public);
                    propDict = property.ToDictionary (p => p.Name.ToUpper (), p => p);
                    while (dr.Read ()) {
                        T newObject = new T ();
                        for (int i = 0; i < dr.FieldCount; i++) {
                            if (propDict.ContainsKey (dr.GetName (i).ToUpper ())) {
                                var Info = propDict[dr.GetName (i).ToUpper ()];
                                if ((Info != null) && Info.CanWrite) {
                                    var val = dr.GetValue (i);
                                    Info.SetValue (newObject, (val == DBNull.Value) ? null : val, null);
                                }
                            }
                        }
                        entitiesList.Add (newObject);
                    }
                }
            } catch (Exception ex) {
                throw ex;
            }
            return entitiesList;
        }

          public static T ToCustomEntity<T> (this DbDataReader dr) where T : class, new () {

            var entity = typeof (T);
            T retVal = null;
            var propDict = new Dictionary<string, PropertyInfo> ();
            try {
                if (dr != null && dr.HasRows) {
                    retVal = new T ();
                    var property = entity.GetProperties (BindingFlags.Instance | BindingFlags.Public);
                    propDict = property.ToDictionary (p => p.Name.ToUpper (), p => p);
                    dr.Read ();
                    for (int i = 0; i < dr.FieldCount; i++) {
                        if (propDict.ContainsKey (dr.GetName (i).ToUpper ())) {
                            var Info = propDict[dr.GetName (i).ToUpper ()];
                            if ((Info != null) && Info.CanWrite) {
                                var val = dr.GetValue (i);
                                Info.SetValue (retVal, (val == DBNull.Value) ? null : val, null);
                            }
                        }
                    }
                }
            } catch (Exception ex) {
                throw ex;
            }
            return retVal;
        }


    }
}