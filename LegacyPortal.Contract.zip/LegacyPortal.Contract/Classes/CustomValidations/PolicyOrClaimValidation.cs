using System;
using System.ComponentModel.DataAnnotations;
using LegacyPortal.Contract.Model.Request;

namespace LegacyPortal.Contract.Classes {
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true, Inherited = false)]
    public class PolicyOrClaimValidation : RequiredAttribute
    {
        private string _errorMessageIfTrue;
        private string _errorMessageIfFalse;

        public PolicyOrClaimValidation(string errorMessageIfTrue, string errorMessageIfFalse)
        {
            _errorMessageIfTrue = errorMessageIfTrue;
            _errorMessageIfFalse = errorMessageIfFalse;
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {

        var mortgageLossPayee = (MortgageLossPayeeRequest)validationContext.ObjectInstance;
        DateTime? postDate = mortgageLossPayee.PostDate;
        bool isPolicy = mortgageLossPayee.IsPolicy;
       
        if (isPolicy == true && postDate == null && postDate is null)
        {
            return new ValidationResult(_errorMessageIfTrue);
        }
        else if (isPolicy == false && postDate != null)
        {
            return new ValidationResult(_errorMessageIfFalse);
        }
        else return ValidationResult.Success;
        }
    }
}