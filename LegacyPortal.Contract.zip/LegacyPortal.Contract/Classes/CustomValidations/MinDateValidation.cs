using System;
using System.ComponentModel.DataAnnotations;

namespace LegacyPortal.Contract.Classes {
    public class MinDateValidation : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            
         DateTime date = Convert.ToDateTime(value);
         string MinValue = "1753-01-01 12:00:00";
         DateTime checkDate = Convert.ToDateTime(MinValue);
         return date >=  checkDate;
        }
    }
}