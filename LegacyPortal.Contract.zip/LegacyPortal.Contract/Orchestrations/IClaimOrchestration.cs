using LegacyPortal.Contract.Data.Request;
using LegacyPortal.Contract.Model.Request;
using LegacyPortal.Contract.Model.Response;

namespace LegacyPortal.Contract.Orchestrations {
    public interface IClaimOrchestration {
        BriefClaimResponse Get (GetClaimRequest claimRequest);
        ClaimResponse GetClaimByClaimId(string claimNumber);
        ClaimHandlingResponse GetClaimsHandling(string claimNumber);
        ClaimActivitiesResponse GetClaimActivitiesList(string claimNumber);
        ClaimPaymentTransactionResponse GetPaymentTransactionInfo(string claimNumber);
        CheckDetailsResponse GetCheckDetails(string checkNumber);
        ClaimContactsAndLocationResponse ClaimContactsAndLocation(string claimNumber);
        GetClaimDocumentResponse GetDocumentDetailsfromJson(GetClaimDocumentRequest docRequest);
        ClaimDataResponse GetClaimData(string claimNumber);
    }
}
