using System;
using System.Threading.Tasks;
using LegacyPortal.Contract.Model.Request;
using LegacyPortal.Contract.Model.Response;

namespace LegacyPortal.Contract.Orchestrations {
    public interface IPolicyOrchestration {
        BriefPolicyResponse Get(PolicyRequest policyRequest);

        AllPolicyResponse GetAllPolicyDetailsByPolicyId(PolicyByIdRequest policyRequest);
        AllCoveragesResponse GetAllCoveragesByPolicyId(PolicyByIdRequest policyRequest);
        CoverageResponse GetCoveragesDetailsByProperty(CoveragesByPropertyRequest propertyRequest);
        NotesResponse GetNotesByPolicyId(NotesRequest propertyRequest);
        FinanceResponse GetPremiumFinanceByPolicyId(PolicyByIdRequest financeRequest);
        TransactionPaymentResponse GetTransactionAndPaymentInfoByPolicyId(NotesRequest request);
        ClaimsByPolicyIdResponse GetClaimsByPolicyId(PolicyByIdRequest claimRequest);
        PostDatesResponse GetPostDates(NotesRequest postDatesRequest);
        PolicyExport GetDocumentDetailsfromJson(PolicyByIdRequest docRequest);
        MortgageLossPayeeResponse GetMortgageLossPayeeDetail(MortgageLossPayeeRequest mortgageRequest);
        TotalTIVResponse GetTotalTIVDetails(PolicyByIdRequest policyRequest);

    }
}