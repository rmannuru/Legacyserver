using System;
using System.Collections.Generic;
using LegacyPortal.Contract.Data.Request;
using LegacyPortal.Contract.Model.Request;
using LegacyPortal.Contract.Model.Response;

namespace LegacyPortal.Business.Orchestrations
{
    public interface ICommonOrchestration {

     int SaveEmailNotificationDetails(EmailNotificationRequest request);   
     EmailNotificationRequest GetEmailNotificationRequest(string senderDetails, List<string> ToDetails, List<string> ccDetails, string featureName,  string emailResponse, Boolean IsMailSent);
      GetSpecificDocumentResponse GetParticularDocument(GetSpecificDocumentRequest request);
    }

}
