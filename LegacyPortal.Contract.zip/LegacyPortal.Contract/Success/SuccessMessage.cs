namespace LegacyPortal.Contract.Success
{
    public class SuccessMessage
    {
        public const string LP_GetPoliciesListSuccess = "Policy list retrieved successfully";
        public const string LP_GetPolicyByIdSuccess = "Policy retrieved successfully";
        public const string LP_GetCoverageSuccess = "Coverages info retrieved successfully";
         public const string LP_GetPropertyCoverageSuccess = "Property coverages retrieved successfully";
        public const string LP_GetClaimsListSuccess = "Claim list retrieved successfully";
        public const string LP_GetNotesSuccess = "Note details retrieved successfully";
        public const string LP_GetFinanceSuccess = "Finance details retrieved successfully";
        public const string LP_GetTransactionPaymentSuccess = "Transation and payment details retrieved successfully";
        public const string LP_GetPostDatesSuccess = "Post dates retrieved successfully";
        public const string LP_DocumentRetrivedSuccessfully = "Documents retrieved successfully";
        public const string LP_GetClaimsByClaimNumberSuccess = "Claims retrieved successfully";
        public const string LP_GetClaimHandlingInfoSuccess = "Claim handling info retrieved successfully";
        public const string LP_ClaimActivitiesListSuccess = "Claim activities list retrieved successfully";
        public const string LP_ClaimPaymentTransactionSuccess = "Claim payment transactions retrieved successfully";
        public const string LP_GetCheckDetailsSuccess = "Check details for claims retrieved successfully";
        public const string LP_ClaimContactsAndLocSuccess = "claim contacts and location details retrieved successfully";
         public const string LP_ClaimDataSuccess = "claim data retrieved successfully";
         public const string LP_GetMorgageLossPayeeDetail = "Mortgage and LossPayee details are retrieved successfully";
         public const string LP_GetTotalTivSuccess = "TotalTIV details are retrieved successfully";

    }
}
    