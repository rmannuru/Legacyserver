namespace LegacyPortal.Contract.Success {
    public enum SuccessCode {
        LP_GetPoliciesListSuccess = 100001,
        LP_GetPolicyByIdSuccess = 100002,
        LP_GetCoverageSuccess = 100003,
        LP_GetClaimsListSuccess = 100004,
        LP_GetNotesSuccess = 100005,
        LP_GetFinanceSuccess = 100006,
        LP_GetTransactionPaymentSuccess = 100007,
        LP_GetPostDatesSuccess = 100008,
        LP_DocumentRetrivedSuccessfully=100009,
        LP_GetClaimsByClaimNumberSuccess = 100010,
        LP_GetClaimHandlingInfoSuccess = 100011,
        LP_ClaimActivitiesListSuccess = 100012,
        LP_ClaimPaymentTransactionSuccess = 100013,
        LP_GetCheckDetailsSuccess = 100014,
        LP_ClaimContactsAndLocSuccess = 100015,
        LP_ClaimDataSuccess = 10016,
        LP_GetPropertyCoverageSuccess = 10017,
        LP_GetMorgageLossPayeeDetail = 10018,
        LP_GetTotalTivSuccess=10019
    }
}