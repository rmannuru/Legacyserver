using System.Data.Common;
using LegacyPortal.Contract.Data.Request;

namespace LegacyPortal.Contract.Data
{
    public interface ICommonDataAccess
    {
        int SaveEmailNotificationDetails(EmailNotificationRequest request);  
    }
}
