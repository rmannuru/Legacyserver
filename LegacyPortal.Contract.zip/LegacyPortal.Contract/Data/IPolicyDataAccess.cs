using System;
using System.Data.Common;
using LegacyPortal.Contract.Model.Request;

namespace LegacyPortal.Contract.Data {
    public interface IPolicyDataAccess {
        DbDataReader Get (PolicyRequest policyRequest);
        DbDataReader GetAllPolicyDetailsByPolicyId(PolicyByIdRequest policyrequest);
        DbDataReader GetAllCoveragesByPolicyId(PolicyByIdRequest policyrequest);
        DbDataReader GetCoveragesDetailsByProperty(CoveragesByPropertyRequest propertyRequest);
        DbDataReader GetNotesByPolicyId(NotesRequest notesRequest);
        DbDataReader GetPremiumFinanceByPolicyId(PolicyByIdRequest financeRequest);
        DbDataReader GetTransactionAndPaymentInfoByPolicyId(NotesRequest request);
        DbDataReader GetClaimsByPolicyId(PolicyByIdRequest claimRequest);
        DbDataReader GetPostDates(NotesRequest postDatesRequest);
        DbDataReader GetMortgageLossPayeeDetail(MortgageLossPayeeRequest mortgageRequest);
        DbDataReader GetTotalTIVDetails(PolicyByIdRequest request);
    }
}