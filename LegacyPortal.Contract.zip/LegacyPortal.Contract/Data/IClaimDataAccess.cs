using System.Data.Common;
using LegacyPortal.Contract.Data.Request;

namespace LegacyPortal.Contract.Data {
    public interface IClaimDataAccess {
        DbDataReader GetClaimList (GetClaimRequest claimRequest);
        DbDataReader GetClaimByClaimId(string claimNumber);
        DbDataReader GetClaimsHandling(string claimNumber);
        DbDataReader GetClaimActivitiesList(string claimNumber);
        DbDataReader GetPaymentTransactionInfo(string claimNumber);
        DbDataReader GetCheckDetails(string checkNumber);
        DbDataReader ClaimContactsAndLocation(string claimNumber);
        DbDataReader GetClaimData(string claimNumber);
    }
}