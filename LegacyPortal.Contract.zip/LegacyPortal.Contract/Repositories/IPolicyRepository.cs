using LegacyPortal.Contract.Model.Request;
using LegacyPortal.Contract.Model.Response;
using System;

namespace LegacyPortal.Contract.Repositories {
    public interface IPolicyRepository {
        BriefPolicyResponse Get(PolicyRequest policyRequest);
        AllPolicyResponse GetAllPolicyDetailsByPolicyId(PolicyByIdRequest policyrequest);
        AllCoveragesResponse GetAllCoveragesByPolicyId(PolicyByIdRequest policyrequest);
        CoverageResponse GetCoveragesDetailsByProperty(CoveragesByPropertyRequest propertyRequest);
        NotesResponse GetNotesByPolicyId(NotesRequest notesRequest);
        FinanceResponse GetPremiumFinanceByPolicyId(PolicyByIdRequest financeRequest);
        TransactionPaymentResponse GetTransactionAndPaymentInfoByPolicyId(NotesRequest request);
        ClaimsByPolicyIdResponse GetClaimsByPolicyId(PolicyByIdRequest claimsRequest);
        PostDatesResponse GetPostDates(NotesRequest postDatesRequest);
        MortgageLossPayeeResponse GetMortgageLossPayeeDetail(MortgageLossPayeeRequest mortgageRequest);
        TotalTIVResponse GetTotalTIVDetails(PolicyByIdRequest policyRequest);
    }
}