using LegacyPortal.Contract.Data.Request;

namespace LegacyPortal.Contract.Repositories
{
    public interface ICommonRepository
    {
        int SaveEmailNotificationDetails(EmailNotificationRequest request);
    }
}