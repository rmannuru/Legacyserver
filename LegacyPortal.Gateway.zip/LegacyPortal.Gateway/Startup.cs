using System;
using System.IO;
using Amazon.S3;
using LegacyPortal.Contract.Classes;
using LegacyPortal.Gateway.Utils;
using LegacyPortal.Gateway.Utils.Extensions;
using LegacyPortal.Gateway.Utils.Filters;
using LegacyPortal.Shared.AppSettings;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace LegacyPortal.Gateway
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc (setupAction => {
                setupAction.ReturnHttpNotAcceptable = true;
                //setupAction.OutputFormatters.Add (new XmlDataContractSerializerOutputFormatter ());

            });
            services.Configure<DbConfig> (Configuration.GetSection (Constants.Config.AppSettings).GetSection (Constants.Config.DbConfiguration));
            services.Configure<EmailConfig> (Configuration.GetSection (Constants.Config.EmailConfig));
             services.Configure<AWSConfig> (Configuration.GetSection (Constants.Config.AWSConfig));

            // var context = new CustomAssemblyLoadContext ();
            // var architectureFolder = (IntPtr.Size == 8) ? "64 bit" : "32 bit";
            // object p = context.LoadUnmanagedLibrary (Path.Combine (Directory.GetCurrentDirectory (), $"lib\\wkhtmltox\\{architectureFolder}\\libwkhtmltox.dll"));

            // services.AddSingleton (typeof (IConverter), new SynchronizedConverter (new PdfTools ()));

            services.AddDefaultAWSOptions(Configuration.GetAWSOptions());
            services.AddAWSService<IAmazonS3>();

            services.RegisterServices ();
            services.AddCors ();
            
            services.Configure<GzipCompressionProviderOptions>(options =>
           options.Level = System.IO.Compression.CompressionLevel.Fastest);
            services.AddResponseCompression(options =>
            {
                options.EnableForHttps = true;
                options.Providers.Add<GzipCompressionProvider>();
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseCors(builder => builder.AllowAnyHeader()
            .AllowAnyMethod()
            .AllowAnyOrigin()
            .AllowCredentials()
            );
            app.UseStaticFiles();
            app.UseMiddleware(typeof(AppExceptionMiddleware));
             app.UseResponseCompression();
      
            app.UseMvc();
        }
    }
}
