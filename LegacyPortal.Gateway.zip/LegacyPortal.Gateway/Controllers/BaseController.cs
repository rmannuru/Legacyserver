using System.Net;
using Microsoft.AspNetCore.Mvc;

namespace LegacyPortal.Gateway.Controllers {
   public class BaseController : Controller {
        private const string LogContextName = "context";
    
        protected void SetLoggingContext (string logMessage)

        {
            var context = HttpContext;

            var contextMessage = GetRequestInfo () + $"[{logMessage}]";

            if (context.Items.ContainsKey (LogContextName)) {

                context.Items[LogContextName] = contextMessage;
            } else {
                context.Items.Add (LogContextName, contextMessage);
            }
        }
        protected string GetLoggingContextMessage () {
            var context = HttpContext;
            if (context.Items.ContainsKey (LogContextName)) {
                return context.Items[LogContextName].ToString ();
            }
            return "";
        }

        protected string GetRequestInfo () {
            var context = HttpContext;
            if (context == null) {
                return null;
            }
            string server = Dns.GetHostName ();

            string requestId = context.Connection.Id;

            var requesterIp = context.Connection.RemoteIpAddress.ToString ();

            string requestUri = context.Request.Path;
            string requestBase = context.Request.PathBase;
            string verb = context.Request.Method;

            string log =
                $"[Server:{server}][RequesterIP:{requesterIp}][Verb:{verb}][RequestUri:{requestUri}][RequestID:{requestId}]";
            return log;
        }

    }
}