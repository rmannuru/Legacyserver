using System;
using System.Net;
using LegacyPortal.Business.Orchestrations;
using LegacyPortal.Contract.Error;
using LegacyPortal.Contract.Model.Request;
using LegacyPortal.Contract.Model.Response;
using LegacyPortal.Contract.Orchestrations;
using LegacyPortal.Contract.Success;
using LegacyPortal.Gateway.Utils.Extensions;
using LegacyPortal.Logging.Contracts;
using Microsoft.AspNetCore.Mvc;
using static LegacyPortal.Contract.Classes.Constants;

namespace LegacyPortal.Gateway.Controllers {
    [Route ("api/common")]
    public class CommonController : BaseController {
    private ILoggerManager _logger;
    private ICommonOrchestration _commonOrchestration;

     public CommonController (ILoggerManager logger, ICommonOrchestration commonOrchestration) : base() {
        _commonOrchestration = commonOrchestration;
        _logger = logger;

    }
    [HttpPost]
        [Route("specificDocument")]
        public  IActionResult GetParticularDocument([FromBody]GetSpecificDocumentRequest request)
        {
            try{
                if(ModelState.IsValid){
                 var result=_commonOrchestration.GetParticularDocument(request);
                  if (result != null) {
                        result.Message = SuccessMessage.LP_DocumentRetrivedSuccessfully;
                        result.Code = (int) SuccessCode.LP_DocumentRetrivedSuccessfully;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_DocumentRetrivedError;
                        errorInfo.Message = ErrorMessage.LP_DocumentRetrivedError;
                    return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch(Exception ex)
            {
                 _logger.SaveExceptionLog (ex, ExceptionCategory.GetDocumentsFailed);
                 throw ex;
            }
        }
    }
}