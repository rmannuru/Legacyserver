using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using LegacyPortal.Contract.Model.Request;
using LegacyPortal.Contract.Orchestrations;
using LegacyPortal.Contract.Model.Response;
using LegacyPortal.Logging.Contracts;
using static LegacyPortal.Contract.Classes.Constants;
using System.Net.Mail;
using LegacyPortal.Gateway.Utils.Extensions;
using LegacyPortal.Contract.Error;
using LegacyPortal.Contract.Success;
using System.Threading.Tasks;
using LegacyPortal.Contract.Data.Request;

namespace LegacyPortal.Gateway.Controllers {
    [Route ("api/policy")]
    public class PolicyController : BaseController {
    private ILoggerManager _logger;
    private IPolicyOrchestration _policyOrchestration;

     public PolicyController (ILoggerManager logger, IPolicyOrchestration policyOrchestration) : base() {
        _policyOrchestration = policyOrchestration;
        _logger = logger;

    }

        /// <summary>
        /// returns the polices.
        /// </summary>
        /// <param name="PolicyRequest"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("policiesList")]
        public IActionResult Get ([FromBody] PolicyRequest request) {
            try {
                     if(ModelState.IsValid) {
                    var result = _policyOrchestration.Get(request);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_GetPoliciesListSuccess;
                        result.Code = (int) SuccessCode.LP_GetPoliciesListSuccess;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                         ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_GetPoliciesError;
                        errorInfo.Message = ErrorMessage.LP_GetPoliciesError;
                        
                        return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                         }
                     }
                    return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
                catch (Exception ex) {
                _logger.SaveExceptionLog (ex, ExceptionCategory.GetPoliciesFailed);
                throw ex;
                }
        }

        /// <summary>
        /// returns Policy info, insured info and Endorsement list.
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        [HttpPost]
        [Route("policyDetails")]
        public IActionResult GetAllPolicyDetailsByPolicyId([FromBody]PolicyByIdRequest request) {

            try {
                 if (ModelState.IsValid) {
                    var result = _policyOrchestration.GetAllPolicyDetailsByPolicyId(request);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_GetPolicyByIdSuccess;
                        result.Code = (int) SuccessCode.LP_GetPolicyByIdSuccess;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                         ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_PolicyNotFound;
                        errorInfo.Message = ErrorMessage.LP_PolicyNotFound;
                        return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));

            } catch (Exception ex) {
                 _logger.SaveExceptionLog (ex, ExceptionCategory.GetPolicyByPolicyId);
                throw ex;
            }
        }

        /// <summary>
        /// returns Policy coverage, Building detail and Outdoor property detail
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        [HttpPost]
        [Route("coverages")]
        public IActionResult GetAllCoveragesByPolicyId([FromBody]PolicyByIdRequest request) {

            try {
                 if (ModelState.IsValid) {
                    var result = _policyOrchestration.GetAllCoveragesByPolicyId(request);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_GetCoverageSuccess;
                        result.Code = (int) SuccessCode.LP_GetCoverageSuccess;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                         ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_CoveragesNotFound;
                        errorInfo.Message = ErrorMessage.LP_CoveragesNotFound;
                        return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));

            } catch (Exception ex) {
                _logger.SaveExceptionLog (ex, ExceptionCategory.GetCoveragesFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns coverage details for the selected Building/Outdoor property.
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        [HttpPost]
        [Route("property/coverages")]
        public IActionResult GetCoveragesDetailsByProperty([FromBody]CoveragesByPropertyRequest request) 
        {
            try {
                if (ModelState.IsValid) {

                var result = _policyOrchestration.GetCoveragesDetailsByProperty(request);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_GetPropertyCoverageSuccess;
                        result.Code = (int) SuccessCode.LP_GetPropertyCoverageSuccess;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_GetPropertyCoverageError;
                        errorInfo.Message = ErrorMessage.LP_GetPropertyCoverageError;
                    return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            } catch (Exception ex) {
                 _logger.SaveExceptionLog (ex, ExceptionCategory.GetPropertyCoveragesFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns Policy notes/notices/memos 
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        [HttpPost]
        [Route("notes")]
        public IActionResult GetNotesByPolicyId([FromBody]NotesRequest request) {
            try {
                if (ModelState.IsValid) {
                    
                var result = _policyOrchestration.GetNotesByPolicyId(request);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_GetNotesSuccess;
                        result.Code = (int) SuccessCode.LP_GetNotesSuccess;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_GetNotesNotFound;
                        errorInfo.Message = ErrorMessage.LP_GetNotesNotFound;
                    return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            } catch (Exception ex) {
                 _logger.SaveExceptionLog (ex, ExceptionCategory.GetNotesFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns Premium finance info
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        [HttpPost]
        [Route("finance")]
        public IActionResult GetPremiumFinanceByPolicyId([FromBody]PolicyByIdRequest request) {
            try {
                if (ModelState.IsValid) {

                var result = _policyOrchestration.GetPremiumFinanceByPolicyId(request);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_GetFinanceSuccess;
                        result.Code = (int) SuccessCode.LP_GetFinanceSuccess;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_GetFinanceError;
                        errorInfo.Message = ErrorMessage.LP_GetFinanceError;
                    return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            } catch (Exception ex) {
                 _logger.SaveExceptionLog (ex, ExceptionCategory.GetPremiumFinanceFailed);
                throw ex;
            }
        }
        
        /// <summary>
        /// returns Transaction and payment information
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        [HttpPost]
        [Route("paymentTransactions")]
        public IActionResult GetTransactionAndPaymentInfoByPolicyId([FromBody] NotesRequest request) {
            try {
                if (ModelState.IsValid) {

                var result = _policyOrchestration.GetTransactionAndPaymentInfoByPolicyId(request);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_GetTransactionPaymentSuccess;
                        result.Code = (int) SuccessCode.LP_GetTransactionPaymentSuccess;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_GetTransactionPaymentError;
                        errorInfo.Message = ErrorMessage.LP_GetTransactionPaymentError;
                    return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            } catch (Exception ex) {
                 _logger.SaveExceptionLog (ex, ExceptionCategory.GetTransactionPaymentFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns Claims information by PolicyId
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        [HttpPost]
        [Route("policyId/claims")]
        public IActionResult GetClaimsByPolicyId([FromBody] PolicyByIdRequest claimRequest) {
            try {
                if (ModelState.IsValid) {

                var result = _policyOrchestration.GetClaimsByPolicyId(claimRequest);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_ClaimDataSuccess;
                        result.Code = (int) SuccessCode.LP_ClaimDataSuccess;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_ClaimDataError;
                        errorInfo.Message = ErrorMessage.LP_ClaimDataError;
                    return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            } catch (Exception ex) {
                _logger.SaveExceptionLog (ex, ExceptionCategory.GetClaimDataFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns PostDates information by PolicyId
        /// </summary>
        /// <param name=" "></param>
        /// <returns></returns>
        [HttpPost]
        [Route("getPostDates")]
        public IActionResult GetPostDates([FromBody] NotesRequest request) {
            try {
                if (ModelState.IsValid) {

                var result = _policyOrchestration.GetPostDates(request);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_GetPostDatesSuccess;
                        result.Code = (int) SuccessCode.LP_GetPostDatesSuccess;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_GetPostDatesError;
                        errorInfo.Message = ErrorMessage.LP_GetPostDatesError;
                    return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            } catch (Exception ex) {
                 _logger.SaveExceptionLog (ex, ExceptionCategory.GetPostDatesFailed);
                throw ex;
            }
        }

        [HttpPost]
        [Route("allDocuments")]
        public  IActionResult GetDocumentDetailsfromJson ([FromBody] PolicyByIdRequest request) {
            try{
                if(ModelState.IsValid)
                {
                 var result=_policyOrchestration.GetDocumentDetailsfromJson(request);
                 if (result != null && !result.DocumentNotavailable) {
                        result.Message = SuccessMessage.LP_DocumentRetrivedSuccessfully;
                        result.Code = (int) SuccessCode.LP_DocumentRetrivedSuccessfully;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else if(result != null && result.DocumentNotavailable){
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_DocumentNotFound;
                        errorInfo.Message = ErrorMessage.LP_DocumentNotFound;
                       return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                    else {
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_DocumentRetrivedError;
                        errorInfo.Message = ErrorMessage.LP_DocumentRetrivedError;
                    return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                 return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch(Exception ex)
            {
                 _logger.SaveExceptionLog (ex, ExceptionCategory.GetDocumentsFailed);
                throw ex;
            }
        }

        [HttpPost]
        [Route("getMortgageLossPayeeDetail")]
        public IActionResult GetMortgageLossPayeeDetail([FromBody]MortgageLossPayeeRequest request) {

            try {
                 if (ModelState.IsValid) {
                    var result = _policyOrchestration.GetMortgageLossPayeeDetail(request);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_GetMorgageLossPayeeDetail;
                        result.Code = (int) SuccessCode.LP_GetMorgageLossPayeeDetail;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                         ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_GetMortgageLossPayeeDetail;
                        errorInfo.Message = ErrorMessage.LP_GetMortgageLossPayeeDetail;
                        return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));

            } catch (Exception ex) {
                 _logger.SaveExceptionLog (ex, ExceptionCategory.GetPolicyByPolicyId);
                throw ex;
            }
        }

        [HttpPost]
        [Route("getTotalTivDetail")]
        public IActionResult GetTotalTIVDetails([FromBody]PolicyByIdRequest request) {

            try {
                 if (ModelState.IsValid) {
                    var result = _policyOrchestration.GetTotalTIVDetails(request);
                    if (result != null) {
                        result.Message = SuccessMessage.LP_GetTotalTivSuccess;
                        result.Code = (int) SuccessCode.LP_GetMorgageLossPayeeDetail;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    } else {
                         ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_GetTotalTivError;
                        errorInfo.Message = ErrorMessage.LP_GetTotalTivError;
                        return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));

            } catch (Exception ex) {
                 _logger.SaveExceptionLog (ex, ExceptionCategory.GetPolicyByPolicyId);
                throw ex;
            }
        }
        
    }
}