using System;
using System.Net;
using LegacyPortal.Contract.Data.Request;
using LegacyPortal.Contract.Error;
using LegacyPortal.Contract.Model.Request;
using LegacyPortal.Contract.Model.Response;
using LegacyPortal.Contract.Orchestrations;
using LegacyPortal.Contract.Success;
using LegacyPortal.Gateway.Controllers;
using LegacyPortal.Gateway.Utils.Extensions;
using LegacyPortal.Logging.Contracts;
using Microsoft.AspNetCore.Mvc;
using static LegacyPortal.Contract.Classes.Constants;

namespace LegacyPortal.Gateway.Controllers
{

    [Route("api/Claims")]
    public class ClaimController : BaseController
    {
        private ILoggerManager _logger;
        private IClaimOrchestration _claimOrchestration;

        public ClaimController(ILoggerManager logger, IClaimOrchestration claimOrchestration) : base()
        {
            _claimOrchestration = claimOrchestration;
            _logger = logger;
        }
        
         /// <summary>
        /// returns  all the claims associated with the user.
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpPost]
        [Route("claimsList")]
        public IActionResult Get([FromBody]GetClaimRequest claimRequest)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = _claimOrchestration.Get(claimRequest);
                    if (result != null)
                    {
                        result.Message = SuccessMessage.LP_GetClaimsListSuccess;
                        result.Code = (int)SuccessCode.LP_GetClaimsListSuccess;

                        return Ok(new CustomResponse(HttpStatusCode.OK, result));
                    }
                    else
                    {
                        ErrorInfo errorInfo = new ErrorInfo();
                        errorInfo.Code = (int)ErrorCode.LP_GetClaimsError;
                        errorInfo.Message = ErrorMessage.LP_GetClaimsError;

                        return Ok(new CustomResponse(HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch (Exception ex)
            {
                _logger.SaveExceptionLog (ex, ExceptionCategory.GetClaimsBySearch);
                throw ex;
            }
        }

        /// <summary>
        /// returns claims basic information by claimNumber
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet]
        [Route("claimDetails")]
        public IActionResult GetClaimByClaimId([FromQuery] string claimNumber)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = _claimOrchestration.GetClaimByClaimId(claimNumber);
                    if (result != null)
                    {
                        result.Message = SuccessMessage.LP_GetClaimsByClaimNumberSuccess;
                        result.Code = (int)SuccessCode.LP_GetClaimsByClaimNumberSuccess;
                        return Ok(new CustomResponse(HttpStatusCode.OK, result));
                    }
                    else
                    {
                        ErrorInfo errorInfo = new ErrorInfo();
                        errorInfo.Code = (int)ErrorCode.LP_GetClaimsByClaimNumberError;
                        errorInfo.Message = ErrorMessage.LP_GetClaimsByClaimNumberError;
                        return Ok(new CustomResponse(HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch (Exception ex)
            {
                _logger.SaveExceptionLog (ex, ExceptionCategory.GetClaimInfoFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns claim handling info
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet]
        [Route("handlingInfo")]
        public IActionResult GetClaimsHandling([FromQuery] string claimNumber)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = _claimOrchestration.GetClaimsHandling(claimNumber);
                    if (result != null)
                    {
                        result.Message = SuccessMessage.LP_GetClaimHandlingInfoSuccess;
                        result.Code = (int)SuccessCode.LP_GetClaimHandlingInfoSuccess;

                        return Ok(new CustomResponse(HttpStatusCode.OK, result));
                    }
                    else
                    {
                        ErrorInfo errorInfo = new ErrorInfo();
                        errorInfo.Code = (int)ErrorCode.LP_GetClaimHandlingInfoError;
                        errorInfo.Message = ErrorMessage.LP_GetClaimHandlingInfoError;
                        return Ok(new CustomResponse(HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch (Exception ex)
            {
               _logger.SaveExceptionLog (ex, ExceptionCategory.ClaimHandlingInfoFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns claims basic information by claimNumber
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet]
        [Route("activitiesList")]
        public IActionResult GetClaimActivitiesList([FromQuery] string claimNumber)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = _claimOrchestration.GetClaimActivitiesList(claimNumber);
                    if (result != null)
                    {
                        result.Message = SuccessMessage.LP_ClaimActivitiesListSuccess;
                        result.Code = (int)SuccessCode.LP_ClaimActivitiesListSuccess;
                        return Ok(new CustomResponse(HttpStatusCode.OK, result));
                    }
                    else
                    {
                        ErrorInfo errorInfo = new ErrorInfo();
                        errorInfo.Code = (int)ErrorCode.LP_ClaimActivitiesListError;
                        errorInfo.Message = ErrorMessage.LP_ClaimActivitiesListError;
                        return Ok(new CustomResponse(HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch (Exception ex)
            {
                _logger.SaveExceptionLog (ex, ExceptionCategory.ClaimActivitiesListFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns payment transaction information by claimNumber
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet]
        [Route("paymentTransactions")]
        public IActionResult GetPaymentTransactionInfo([FromQuery] string claimNumber)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = _claimOrchestration.GetPaymentTransactionInfo(claimNumber);
                    if (result != null)
                    {
                        result.Message = SuccessMessage.LP_ClaimPaymentTransactionSuccess;
                        result.Code = (int)SuccessCode.LP_ClaimPaymentTransactionSuccess;
                        return Ok(new CustomResponse(HttpStatusCode.OK, result));
                    }
                    else
                    {
                        ErrorInfo errorInfo = new ErrorInfo();
                        errorInfo.Code = (int)ErrorCode.LP_ClaimPaymentTransactionsError;
                        errorInfo.Message = ErrorMessage.LP_ClaimPaymentTransactionsError;
                        return Ok(new CustomResponse(HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch (Exception ex)
            {
               _logger.SaveExceptionLog (ex, ExceptionCategory.GetClaimPaymentFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns payment transaction information by claimNumber
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet]
        [Route("paymentTransactions/checkDetails")]
        public IActionResult GetCheckDetails([FromQuery] string checkNumber)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = _claimOrchestration.GetCheckDetails(checkNumber);
                    if (result != null)
                    {
                        result.Message = SuccessMessage.LP_GetCheckDetailsSuccess;
                        result.Code = (int)SuccessCode.LP_GetCheckDetailsSuccess;
                        return Ok(new CustomResponse(HttpStatusCode.OK, result));
                    }
                    else
                    {
                        ErrorInfo errorInfo = new ErrorInfo();
                        errorInfo.Code = (int)ErrorCode.LP_GetCheckDetailsError;
                        errorInfo.Message = ErrorMessage.LP_GetCheckDetailsError;
                        return Ok(new CustomResponse(HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch (Exception ex)
            {
               _logger.SaveExceptionLog (ex, ExceptionCategory.GetCheckDetailsFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns contacts and location of claim
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet]
        [Route("contactsAndLocation")]
        public IActionResult ClaimContactsAndLocation([FromQuery] string claimNumber)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = _claimOrchestration.ClaimContactsAndLocation(claimNumber);
                    if (result != null)
                    {
                        result.Message = SuccessMessage.LP_ClaimContactsAndLocSuccess;
                        result.Code = (int)SuccessCode.LP_ClaimContactsAndLocSuccess;
                        return Ok(new CustomResponse(HttpStatusCode.OK, result));
                    }
                    else
                    {
                        ErrorInfo errorInfo = new ErrorInfo();
                        errorInfo.Code = (int)ErrorCode.LP_ClaimContactsAndLocError;
                        errorInfo.Message = ErrorMessage.LP_ClaimContactsAndLocError;
                        return Ok(new CustomResponse(HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch (Exception ex)
            {
                _logger.SaveExceptionLog (ex, ExceptionCategory.ClaimContactsAndLocFailed);
                throw ex;
            }
        }

        /// <summary>
        /// returns policyId, clainNumber, inceptionDate
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet]
        [Route("claimdata")]
        public IActionResult GetClaimData([FromQuery] string claimNumber)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = _claimOrchestration.GetClaimData(claimNumber);
                    if (result != null)
                    {
                        result.Message = SuccessMessage.LP_ClaimDataSuccess;
                        result.Code = (int)SuccessCode.LP_ClaimDataSuccess;
                        return Ok(new CustomResponse(HttpStatusCode.OK, result));
                    }
                    else
                    {
                        ErrorInfo errorInfo = new ErrorInfo();
                        errorInfo.Code = (int)ErrorCode.LP_ClaimDataError;
                        errorInfo.Message = ErrorMessage.LP_ClaimDataError;
                        return Ok(new CustomResponse(HttpStatusCode.Conflict, errorInfo));
                    }
                }
                return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch (Exception ex)
            {
                _logger.SaveExceptionLog (ex, ExceptionCategory.GetClaimDataFailed);
                throw ex;
            }
        }
        [HttpPost]
        [Route("allDocuments")]
        public  IActionResult GetDocumentDetailsfromJson ([FromBody] GetClaimDocumentRequest request) {
            try{
                if(ModelState.IsValid)
                {
                 var result=_claimOrchestration.GetDocumentDetailsfromJson(request);
                 if (result != null && !result.DocumentNotavailable) {
                        result.Message = SuccessMessage.LP_DocumentRetrivedSuccessfully;
                        result.Code = (int) SuccessCode.LP_DocumentRetrivedSuccessfully;
                        return Ok (new CustomResponse (HttpStatusCode.OK, result));
                    }else if(result != null && result.DocumentNotavailable){
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_DocumentNotFound;
                        errorInfo.Message = ErrorMessage.LP_DocumentNotFound;
                       return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    } else {
                        ErrorInfo errorInfo = new ErrorInfo ();
                        errorInfo.Code = (int) ErrorCode.LP_DocumentRetrivedError;
                        errorInfo.Message = ErrorMessage.LP_DocumentRetrivedError;
                    return Ok (new CustomResponse (HttpStatusCode.Conflict, errorInfo));
                    }
                }
                 return Ok (new CustomResponse (HttpStatusCode.BadRequest, ModelState.AllErrors ()));
            }
            catch(Exception ex)
            {
              _logger.SaveExceptionLog (ex, ExceptionCategory.GetDocumentsFailed);
               throw ex;
            }
        }
    }
}

