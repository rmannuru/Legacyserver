using System;
using System.Net;
using System.Threading.Tasks;
using LegacyPortal.Contract.Classes;
using LegacyPortal.Contract.Error;
using LegacyPortal.Logging.Contracts;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using static LegacyPortal.Contract.Classes.Constants;

namespace LegacyPortal.Gateway.Utils.Filters {
    public class AppExceptionMiddleware {
        private readonly RequestDelegate next;

        private ILoggerManager _logger;
      
        public AppExceptionMiddleware (RequestDelegate next, ILoggerManager logger) {
            this.next = next;
            _logger = logger;

        }

        public async Task Invoke (HttpContext context) {
            try {
                await next (context);
            } catch (Exception ex) {
                _logger.SaveExceptionLog(ex,ExceptionCategory.FailedInMiddleware);
                await HandleExceptionAsync (context, ex);
            }
        }

        private static Task HandleExceptionAsync (HttpContext context, Exception exception) {
            var status = HttpStatusCode.InternalServerError;
            var message =  Constants.ApplicationException.InternalServerError;
            bool IsRefreshTokenRequired = false;

            if (exception.GetType () == typeof (UnauthorizedAccessException)) {
                message = exception.Message;
                status = HttpStatusCode.Unauthorized;
               
            } else if (exception.GetType () == typeof (NotImplementedException)) {
                message = Constants.ApplicationException.NotImplementedException;
                status = HttpStatusCode.NotImplemented;
            } else {
                message = Constants.ApplicationException.InternalServerError;
                status = HttpStatusCode.InternalServerError;
            }

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int) status;

            string result = AppExceptionMiddleware.getExceptionResponseBody (exception, context.Response.StatusCode, message, IsRefreshTokenRequired);
            return context.Response.WriteAsync (result);
        }

        private static string getExceptionResponseBody (Exception exception, int statusCode, String message, bool _isRefreshTokenRequired) {
            var error = new ErrorInfo ();
            error.Code = statusCode;
            error.Message = message;
            error.Description = null;
          //  error.IsRefreshTokenRequired = _isRefreshTokenRequired;

            return JsonConvert.SerializeObject (error);
        }
    }
}