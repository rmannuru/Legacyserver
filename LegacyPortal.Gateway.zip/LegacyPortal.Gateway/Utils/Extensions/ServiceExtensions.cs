using LegacyPortal.Data.Implementations;
using LegacyPortal.Business.Orchestrations;
using LegacyPortal.Business.Repositories;
using LegacyPortal.Contract.Data;
using LegacyPortal.Contract.Orchestrations;
using LegacyPortal.Contract.Repositories;
using Microsoft.Extensions.DependencyInjection;
using LegacyPortal.Logging.Contracts;
using LegacyPortal.Logging.Implementations;
using LegacyPortal.Shared.Email;
using Amazon.S3;

namespace LegacyPortal.Gateway.Utils.Extensions {
    public static class ServiceExtensions {
         public static IServiceCollection RegisterServices(this IServiceCollection services) {

            services.AddSingleton<ILoggerManager, LoggerManager> ();
            services.AddSingleton<SmtpEmail>();

            services.AddSingleton<ICommonOrchestration, CommonOrchestration>();
            services.AddSingleton<ICommonRepository, CommonRepository>();
            services.AddSingleton<ICommonDataAccess, CommonDataAccess>();
            
            //Business 
            services.AddSingleton<IPolicyOrchestration, PolicyOrchestration> ();
            services.AddSingleton<IPolicyRepository, PolicyRepository> ();
            services.AddSingleton<IPolicyDataAccess, PolicyDataAccess> ();
            
            services.AddSingleton<IClaimOrchestration, ClaimOrchestration> ();
            services.AddSingleton<IClaimRepository, ClaimRepository> ();
            services.AddSingleton<IClaimDataAccess, ClaimDataAccess> ();
             
            services.AddSingleton<IAmazonS3, AmazonS3Client>();
           
            return services;
        }

    }
}